import React from 'react';
import FormElement from '../FormElement/FormElement.jsx';

// make n-level nested sub components from form data
function makeSubComponentsFromFormData(formData) {
  return formData;
}

export default function FormSubComponent(props) {
  return render();
}
