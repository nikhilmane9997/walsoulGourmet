import React from "react";
import Button from "react-bootstrap/lib/Button";
import _get from "lodash/get";
import moment from "moment";
import AliceCarousel from "react-alice-carousel";
import "react-alice-carousel/lib/alice-carousel.css";
import MaModal from "../Common/MaterialUIModal.jsx";
import "react-responsive-modal/styles.css";
import { Modal } from "react-responsive-modal";
// import { Slider, InputNumber } from 'antd';
import calendarImage from "../../assets/images/select-date.png";
import lazyLoader from "../../assets/svg/loader.gif";
import circle from "../../assets/svg/circle.svg";
import danger from "../../assets/images/warning-4-16.png";
import Image from "react-image-resizer";
import { defaultMergeProps } from "react-redux/lib/connect/mergeProps";

export default function MyCartComponent(props) {
  console.log(props);
  let result = [];
  if (props.totalCartItems.length !== 0) {
    // result = _get(props.cartResult.items);
    /// console.log(props.cartResult.items);

    // const subTotal = _get(props.cartResult, [0, 'subtotal']);
    return (
      <div>
        <div className="">
          <div style={{ border: "2px solid #eaeaea" }} id="All">
            <div className="row">
              <div className="col-lg-5 col-md-5 col-xs-5 col-sm-5"></div>
              <div className="col-lg-3 col-md-3 col-xs-3 col-sm-3"></div>
              <div className="col-lg-4 col-md-4 col-xs-4 col-sm-4">
                <div className="row" style={{ marginTop: "15px" }} id="comp">
                  <div className="col-md-4">
                    <p id="quanty" style={{ color: "black" }}>
                      {props.translate("QTY")}
                    </p>
                  </div>
                  <div className="col-md-4">
                    <p style={{ color: "black" }}>{props.translate("PRICE")}</p>
                  </div>
                  <div className="col-md-4">
                    <p style={{ color: "black" }}>
                      {props.translate("TOTALS")}
                    </p>
                  </div>
                </div>
              </div>
            </div>
            {props.totalCartItems.map((thisCart, index) => {
              return (
                <div
                  key={index}
                  className="row"
                  style={{ minHeight: "165px" }}
                  key={index}
                >
                  <div className="col-lg-5 col-md-5 col-xs-5 col-sm-5">
                    <React.Fragment>
                      <div>
                        <div className="row">
                          <div className="col-lg-6 ">
                            <div className="row" style={{ marginLeft: "0px" }}>
                              <div
                                className="col-md-2"
                                style={{
                                  marginLeft: "-25px",
                                  marginTop: "56px",
                                }}
                              >
                                <a
                                  style={{ cursor: "pointer" }}
                                  onClick={() =>
                                    props.removeProduct(thisCart.item_id)
                                  }
                                >
                                  <img
                                    src={circle}
                                    style={{ height: "20px", width: "20px" }}
                                  />
                                </a>
                              </div>
                              <div className="col-md-10" id="imag">
                                <div
                                  id="bordered"
                                  style={{ border: "1px solid #eaeaea" }}
                                >
                                  <img src={thisCart.image} />
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-lg-6 " id="detail">
                            <p style={{ color: "black" }}>{thisCart.name}</p>
                            {/*<center>
                                                      <a style={{color:'#8AB77D',cursor:'pointer'}} onClick={() => props.removeProduct(thisCart.item_id)}>(Remove)</a>
                                                   </center>*/}

                            {thisCart.attribute_set.id === "11" && (
                              <div style={{ color: "black" }}>
                                <p style={{ color: "black" }}>
                                  {props.translate("CONSULATION_DATE")} :{" "}
                                  {thisCart.custom_attributes.delivery_date}
                                </p>
                                <p>
                                  {props.translate("TIME_SLOT")}:{" "}
                                  {thisCart.custom_attributes.time_slot_from}
                                  &nbsp;&nbsp;&nbsp;&nbsp;
                                  {thisCart.isExpired && (
                                    <img
                                      style={{ marginTop: "-2px" }}
                                      src={danger}
                                    />
                                  )}
                                </p>
                                <p>
                                  {props.translate("CONSULTATION_TYPE")}:{" "}
                                  {thisCart.custom_attributes.consultation_type}
                                </p>
                              </div>
                            )}

                            {(thisCart.attribute_set.id === "13" ||
                              thisCart.attribute_set.id === "11") && (
                              <a onClick={() => props.openEditPopUp(thisCart)}>
                                <span
                                  style={{
                                    color: "#4B817B",
                                    textDecoration: "underline",
                                  }}
                                >
                                  <i
                                    class="fas fa-edit"
                                    style={{ fontSize: "14px" }}
                                  ></i>
                                  {props.translate("CHANGE_SLOT")}
                                </span>
                              </a>
                            )}
                            {/* <p className="cart-deli-date">Delivery Date : {moment(thisCart.delivery_date, 'YYYY-MM-DD').format('DD MMM YYYY')}<img className="cart-calendar" src={ calendarImage }></img></p> */}
                            {/* <p className="cart-deli">Delivery Method : {thisCart.delivery_method}</p> 
                                                        <div style={{ cursor: 'pointer' }} onClick={() => props.removeProduct(thisCart.item_id)} title='Remove Item'>Delete</div>*/}
                          </div>
                        </div>
                      </div>
                    </React.Fragment>
                  </div>

                  <div className="col-lg-3 col-md-3 col-xs-3 col-sm-3">
                    <div className="row">
                      <div
                        className="col-md-12"
                        style={{ marginTop: "25px", marginLeft: "-20px" }}
                      >
                        {thisCart.prescription_required === "yes" && (
                          <p style={{ color: "blue" }}>
                            {props.translate("PRESCRIPTION_REQUIRED")}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-4 col-md-4 col-xs-4 col-sm-4">
                    <div className="row" style={{ marginTop: "25px" }}>
                      <div className="col-md-4" id="qty">
                        <p style={{ color: "black" }}>
                          {/* <div className="cart-info quantity">
                                                                <div className="btn-increment-decrement" onClick={() => props.updateCart(thisCart,'sub',thisCart.qty)}>-</div>
                                                                 <input className="input-quantity" id="input-quantity-wristWear03" value={thisCart.qty}/>
                                                               <div className="btn-increment-increment" onClick={() => props.updateCart(thisCart,'add',thisCart.qty)}>+</div>
                                                              </div> */}
                          {thisCart.attribute_set.name === "Buy Medicine" && (
                            <div className="input-counter">
                              <a
                                onClick={() =>
                                  props.updateCart(
                                    thisCart,
                                    "sub",
                                    thisCart.qty
                                  )
                                }
                              >
                                <span className="input-counter__minus fas fa-minus"></span>
                              </a>

                              <input
                                className="input-counter__text input-counter--text-primary-style"
                                type="text"
                                value={thisCart.qty}
                                data-min="1"
                                data-max="10"
                              />

                              <a
                                onClick={() =>
                                  props.updateCart(
                                    thisCart,
                                    "add",
                                    thisCart.qty
                                  )
                                }
                              >
                                <span className="input-counter__plus fas fa-plus"></span>
                              </a>
                            </div>
                          )}
                        </p>
                      </div>

                      <div className="col-md-4" id="price">
                        <p style={{ color: "black" }}>
                          &#8377;{thisCart.price}
                        </p>
                      </div>
                      <div className="col-md-4" id="pric">
                        <p style={{ color: "black" }}>
                          &#8377;{thisCart.row_total}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}

            <br />
            {props.showPrescription === true && (
              <div>
                <div className="row">
                  <div className="col-md-6">
                    <label
                      style={{
                        marginLeft: "25px",
                        padding: "10px",
                        background: "#007abf",
                        display: "table",
                        color: "#fff",
                        width: "166px",
                        border: "#007abf",
                        borderRadius: "15px",
                      }}
                    >
                      {props.translate("UPLOAD_PRESCRIPTION")}
                      <input
                        type="file"
                        name="file"
                        onChange={(e) => props.changePrescription(e)}
                      />
                    </label>
                  </div>
                  <div className="col-md-6">
                    {props.showPrescriptionLoader && (
                      <span>
                        <div class="spinner-border btn--icon"></div>
                      </span>
                    )}
                  </div>
                </div>
                <br />
                <div className="row">
                  {props.prescQuoteData !== undefined &&
                    props.prescQuoteData.map((contact) => (
                      <div className="col-md-3">
                        <div
                          style={{
                            border: "2px solid grey",
                            width: "60%",
                            marginLeft: "10%",
                          }}
                        >
                          <a
                            style={{ float: "right" }}
                            onClick={() => props.deletePres(contact.id)}
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="16"
                              height="16"
                              fill="currentColor"
                              class="bi bi-x-square"
                              viewBox="0 0 16 16"
                            >
                              <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                              <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                            </svg>
                          </a>
                          <center>
                            <img
                              src={contact.filename}
                              style={{ height: "100px", width: "100px" }}
                            />
                            {/* <button onClick={(e) => props.changePrescription(e)}>Remove</button>  */}
                          </center>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            )}

            <br />
            <br />
          </div>

          <br />

          <div style={{ border: "2px solid #eaeaea", padding: "15px" }}>
            <div className="row">
              <div className="col-lg-4 col-md-6 ">
                <div
                  style={{ border: "1px solid #eaeaea", padding: "20px" }}
                  id="bill"
                >
                  <br />
                  <center>
                    <p style={{ color: "black" }}>
                      {props.translate("SHIPPING_ADDRESS")}
                    </p>
                  </center>
                  <br />
                  <ul className="form-list">
                    <li className="fields row">
                      <div style={{ display: "none" }} className="input-field">
                        <input
                          name="addressId"
                          id="addressId"
                          title="Address ID"
                          className="field-input"
                          type="text"
                          value={props.fields.addressId}
                        />
                      </div>
                      <div class="form-group col-sm-6">
                        <input
                          name="firstName"
                          id="firstName"
                          autocomplete="new-password"
                          title="First Name"
                          placeholder={props.translate("FIRST")}
                          className={
                            props.errors.firstName
                              ? "form-control redData"
                              : "form-control"
                          }
                          type="text"
                          onChange={props.handleChange}
                          value={props.fields.firstName}
                        />
                      </div>
                      <div className="input-field col-sm-6">
                        <input
                          name="lastName"
                          id="lastName"
                          autocomplete="new-password"
                          title="Last Name"
                          placeholder={props.translate("LAST")}
                          className={
                            props.errors.lastName
                              ? "form-control redData"
                              : "form-control"
                          }
                          type="text"
                          onChange={props.handleChange}
                          value={props.fields.lastName}
                        />
                      </div>
                    </li>
                    <li className="fields row">
                      <div className="form-group col-sm-6" id="phone">
                        <input
                          name="telephone"
                          id="telephone"
                          autocomplete="new-password"
                          title="Telephone"
                          className={
                            props.errors.telephone
                              ? "form-control redData"
                              : "form-control"
                          }
                          type="text"
                          placeholder={props.translate("PHONE_NO")}
                          onChange={props.handleChange}
                          value={props.fields.telephone}
                        />
                      </div>
                      <div
                        className="form-group col-sm-6"
                        style={{ display: "none" }}
                      >
                        <input
                          name="company"
                          id="company"
                          autocomplete="new-password"
                          title="Company"
                          className="form-control"
                          type="text"
                          placeholder={props.translate("COMPANY")}
                          onChange={props.handleChange}
                          value={props.fields.company}
                        />
                      </div>
                    </li>
                    <li className="fields row">
                      <div className="form-group col-sm-12">
                        <input
                          name="streetAddress1"
                          id="streetAddress1"
                          autocomplete="new-password"
                          title="Street Address1"
                          className={
                            props.errors.streetAddress1
                              ? "form-control redData"
                              : "form-control"
                          }
                          type="text"
                          placeholder={props.translate("STREET_ADDRESS1")}
                          onChange={props.handleChange}
                          value={props.fields.streetAddress1}
                        />
                      </div>
                    </li>
                    <li className="fields row">
                      <div className="form-group col-sm-12">
                        <input
                          name="streetAddress2"
                          id="streetAddress2"
                          autocomplete="new-password"
                          title="Street Address2"
                          className="form-control"
                          type="text"
                          placeholder={props.translate("STREET_ADDRESS2")}
                          onChange={props.handleChange}
                          value={props.fields.streetAddress2}
                        />
                      </div>
                    </li>
                    <li className="fields row">
                      <div className="form-group col-sm-6">
                        <input
                          name="city"
                          id="city"
                          required
                          title="City"
                          autocomplete="new-password"
                          className={
                            props.errors.city
                              ? "form-control redData"
                              : "form-control"
                          }
                          type="text"
                          placeholder={props.translate("CITY")}
                          onChange={props.handleChange}
                          value={props.fields.city}
                        />
                      </div>
                      <div className="form-group col-sm-6">
                        <select
                          className={
                            props.errors.selectStateValueShipping
                              ? "form-control redData"
                              : "form-control"
                          }
                          required
                          id="billing_region_id_1"
                          name="region_id"
                          title="State/Province"
                          value={props.selectStateValueShipping}
                          onChange={props.handleStateChange}
                        >
                          <option value="">
                            {props.translate("SELECT_REGION")}
                          </option>
                          {props.stateListRes.length !== 0 &&
                            Object.entries(
                              props.stateListRes.available_region
                            ).map(([value, thisState]) => (
                              <option
                                key={value}
                                /* value={`${thisState.code},${thisState.region_id}`} */ value={
                                  thisState.id
                                }
                                id={thisState.id}
                                alt={thisState.id}
                              >
                                {thisState.name}
                              </option>
                            ))}
                        </select>
                      </div>
                    </li>
                    <li className="fields row">
                      <div className="form-group col-sm-12">
                        <input
                          name="postalCode"
                          required
                          id="postalCode"
                          autocomplete="new-password"
                          title="Postal Code"
                          className="form-control"
                          type="text"
                          placeholder={props.translate("PSTAL_CODE")}
                          onChange={props.handleChange}
                          value={props.fields.postalCode}
                        />
                      </div>
                    </li>
                    {props.shipAddress !== undefined ? (
                      <li className="fields row">
                        <div className="input-checkbox form-group col-sm-12">
                          <React.Fragment>
                            <input
                              type="checkbox"
                              name="defBillAdd"
                              id="defBillAdd"
                              title="Use as My Default Billing Address"
                              onChange={props.handleChangeBill}
                              value={props.defBillAdd}
                            />
                            <label>
                              {" "}
                              &nbsp;
                              {props.translate(
                                "USE_SHIPPING_AS_A_BILLING_ADDRESS"
                              )}
                            </label>
                          </React.Fragment>
                        </div>
                      </li>
                    ) : (
                      <li className="fields row">
                        <div className="input-checkbox form-group col-sm-12">
                          <React.Fragment>
                            <input
                              type="checkbox"
                              disabled
                              name="defBillAdd"
                              id="defBillAdd"
                              title="Use as My Default Billing Address"
                              onChange={props.handleChangeBill}
                              value={props.defBillAdd}
                            />
                            <label>
                              {" "}
                              &nbsp;
                              {props.translate(
                                "USE_SHIPPING_AS_A_BILLING_ADDRESS"
                              )}
                            </label>
                          </React.Fragment>
                        </div>
                      </li>
                    )}
                  </ul>
                  {props.showShippingLoader !== true ? (
                    <div className="row" id="buttn">
                      <div className="col-xs-12" id="margin_flex">
                        {props.shipAddress === undefined ? (
                          <center>
                            <input
                              onClick={() => props.handleSaveAddress()}
                              type="submit"
                              style={{
                                padding: "5px",
                                ackgroundColor: "#1d708a",
                                color: "white",
                                width: "100px",
                                height: "35px",
                                borderRadius: "25px",
                                border: "1px solid",
                              }}
                              className="field_bt"
                              value={props.translate("SAVE_ADDRESS")}
                            />
                          </center>
                        ) : (
                          <div className="row" id="button_Align">
                            <div className="col-xs-6">
                              <center>
                                <input
                                  onClick={() => props.handleSaveAddress()}
                                  type="submit"
                                  style={{
                                    padding: "5px",
                                    backgroundColor: "#1d708a",
                                    color: "white",
                                    width: "100px",
                                    height: "35px",
                                    borderRadius: "25px",
                                    border: "1px solid",
                                  }}
                                  className="field_bt"
                                  value={props.translate("SAVE_ADDRESS")}
                                />
                              </center>
                            </div>
                            <div className="col-xs-6">
                              <center>
                                <input
                                  id="L_medi"
                                  onClick={() =>
                                    props.showAddressModal("shipping")
                                  }
                                  type="submit"
                                  style={{
                                    padding: "5px",
                                    backgroundColor: "#1d708a",
                                    color: "white",
                                    width: "140px",
                                    height: "35px",
                                    borderRadius: "25px",
                                    border: "1px solid",
                                  }}
                                  className="field_bt"
                                  value={props.translate("CHANGE_ADDRESS")}
                                />
                              </center>
                            </div>
                          </div>
                        )}
                      </div>
                      {/*<div className="col-xs-6">
                                         <center>
                                            <input onClick={() => props.showAddressModal('shipping')} type="submit" style={{backgroundColor: '#1d708a',color: 'white',width:'140px',height:'35px',borderRadius: '25px',border:'1px solid'}} className="field_bt" value={props.translate('CHANGE_ADDRESS')}/>
                                        </center>
                                      </div>*/}
                    </div>
                  ) : (
                    <div
                      className="row"
                      style={{ marginBottom: "35px", marginTop: "65px" }}
                    >
                      <div className="col-md-12">
                        <center>
                          <img
                            src={lazyLoader}
                            style={{ height: "60px", width: "60px" }}
                            alt="lazy-loader"
                          />
                        </center>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="col-lg-4 col-md-6" id="bill">
                <div id="respom">
                  <br />
                  <center>
                    <p style={{ color: "black" }}>
                      {props.translate("BILLING_ADDRESS")}
                    </p>
                  </center>
                  <br />
                  <ul className="form-list">
                    <li className="fields row">
                      <div style={{ display: "none" }} className="input-field">
                        <input
                          name="addressId"
                          id="addressId"
                          title="Address ID"
                          className="field-input"
                          type="text"
                          value={props.fields1.addressId}
                        />
                      </div>
                      <div class="form-group col-sm-6">
                        <input
                          name="firstName"
                          id="firstName"
                          disabled={props.defBillAdd}
                          autocomplete="new-password"
                          title="First Name"
                          placeholder={props.translate("FIRST")}
                          className={
                            props.errors1.firstName
                              ? "form-control redData"
                              : "form-control"
                          }
                          type="text"
                          onChange={props.handleChange1}
                          value={props.fields1.firstName}
                        />
                      </div>
                      <div className="input-field col-sm-6">
                        <input
                          name="lastName"
                          id="lastName"
                          disabled={props.defBillAdd}
                          autocomplete="new-password"
                          title="Last Name"
                          placeholder={props.translate("LAST")}
                          className={
                            props.errors1.lastName
                              ? "form-control redData"
                              : "form-control"
                          }
                          type="text"
                          onChange={props.handleChange1}
                          value={props.fields1.lastName}
                        />
                      </div>
                    </li>
                    <li className="fields row">
                      <div className="form-group col-sm-6" id="phone">
                        <input
                          name="telephone"
                          id="telephone"
                          disabled={props.defBillAdd}
                          autocomplete="new-password"
                          title="Telephone"
                          className={
                            props.errors1.telephone
                              ? "form-control redData"
                              : "form-control"
                          }
                          type="text"
                          placeholder={props.translate("PHONE_NO1")}
                          onChange={props.handleChange1}
                          value={props.fields1.telephone}
                        />
                      </div>
                      <div
                        className="form-group col-sm-6"
                        style={{ display: "none" }}
                      >
                        <input
                          name="company"
                          id="company"
                          autocomplete="new-password"
                          disabled={props.defBillAdd}
                          title="Company"
                          className="form-control"
                          type="text"
                          placeholder={props.translate("COMPANY")}
                          onChange={props.handleChange1}
                          value={props.fields1.company}
                        />
                      </div>
                    </li>
                    <li className="fields row">
                      <div className="form-group col-sm-12">
                        <input
                          name="streetAddress1"
                          id="streetAddress1"
                          disabled={props.defBillAdd}
                          autocomplete="new-password"
                          title="Street Address1"
                          className={
                            props.errors1.streetAddress1
                              ? "form-control redData"
                              : "form-control"
                          }
                          type="text"
                          placeholder={props.translate("STREET_ADDRESS1")}
                          onChange={props.handleChange1}
                          value={props.fields1.streetAddress1}
                        />
                      </div>
                    </li>
                    <li className="fields row">
                      <div className="form-group col-sm-12">
                        <input
                          name="streetAddress2"
                          id="streetAddress2"
                          disabled={props.defBillAdd}
                          autocomplete="new-password"
                          title="Street Address2"
                          className="form-control"
                          type="text"
                          placeholder={props.translate("STREET_ADDRESS2")}
                          onChange={props.handleChange1}
                          value={props.fields1.streetAddress2}
                        />
                      </div>
                    </li>
                    <li className="fields row">
                      <div className="form-group col-sm-6">
                        <input
                          name="city"
                          id="city"
                          title="City"
                          disabled={props.defBillAdd}
                          required
                          autocomplete="new-password"
                          className={
                            props.errors1.city
                              ? "form-control redData"
                              : "form-control"
                          }
                          type="text"
                          placeholder={props.translate("CITY")}
                          onChange={props.handleChange1}
                          value={props.fields1.city}
                        />
                      </div>
                      <div className="form-group col-sm-6">
                        <select
                          className={
                            props.errors1.selectCountryValueBilling
                              ? "form-control redData"
                              : "form-control"
                          }
                          id="billing_region_id_1"
                          name="region_id"
                          title="Country"
                          value={props.selectCountryValueBilling}
                          onChange={props.handleCountryChange}
                        >
                          <option value="">
                            {props.translate("SELECT_COUNTRY")}
                          </option>
                          {props.countryData &&
                            Object.entries(props.countryData).map(
                              ([value, thisState]) => (
                                <option
                                  key={value}
                                  /* value={`${thisState.code},${thisState.region_id}`} */ value={
                                    thisState.Code
                                  }
                                  id={thisState.Code}
                                  alt={thisState.Code}
                                >
                                  {thisState.Name}
                                </option>
                              )
                            )}
                        </select>
                      </div>
                    </li>
                    <li className="fields row">
                      <div className="form-group col-sm-6">
                        <select
                          className={
                            props.errors1.selectStateValueBilling
                              ? "form-control redData"
                              : "form-control"
                          }
                          id="billing_region_id_1"
                          name="region_id"
                          title="State/Province"
                          value={props.selectStateValueBilling}
                          onChange={props.handleStateChange1}
                        >
                          <option value="">
                            {props.translate("SELECT_REGION")}
                          </option>
                          {props.billStateRes.length !== 0 &&
                            Object.entries(
                              props.billStateRes.available_region
                            ).map(([value, thisState]) => (
                              <option
                                key={value}
                                /* value={`${thisState.code},${thisState.region_id}`} */ value={
                                  thisState.id
                                }
                                id={thisState.id}
                                alt={thisState.id}
                              >
                                {thisState.name}
                              </option>
                            ))}
                        </select>
                      </div>
                      <div className="form-group col-sm-6">
                        <input
                          name="postalCode"
                          id="postalCode"
                          disabled={props.defBillAdd}
                          required
                          autocomplete="new-password"
                          title="Postal Code"
                          className={
                            props.errors1.postalCode
                              ? "form-control redData"
                              : "form-control"
                          }
                          type="text"
                          placeholder={props.translate("PSTAL_CODE")}
                          onChange={props.handleChange1}
                          value={props.fields1.postalCode}
                        />
                      </div>
                    </li>
                  </ul>
                  <br />

                  {props.showBillingLoader !== true ? (
                    <div id="shift-button">
                      {props.defBillAdd === true ? (
                        <div className="row" style={{ marginBottom: "36px" }}>
                          <div className="col-md-12">
                            <center>
                              <input
                                onClick={() =>
                                  props.showAddressModal("billing")
                                }
                                type="submit"
                                style={{
                                  padding: "5px",
                                  backgroundColor: "#1d708a",
                                  color: "white",
                                  width: "140px",
                                  height: "35px",
                                  borderRadius: "25px",
                                  border: "1px solid",
                                }}
                                className="field_bt"
                                value={props.translate("CHANGE_ADDRESS")}
                              />
                            </center>
                          </div>
                        </div>
                      ) : (
                        <div className="row" id="buttons">
                          <div className="col-xs-12" id="medButt">
                            {props.billAddress === undefined ? (
                              <center>
                                <input
                                  onClick={() =>
                                    props.handleSaveBillingAddress()
                                  }
                                  type="submit"
                                  style={{
                                    padding: "5px",
                                    backgroundColor: "#1d708a",
                                    color: "white",
                                    width: "100px",
                                    height: "35px",
                                    borderRadius: "25px",
                                    border: "1px solid",
                                  }}
                                  className="field_bt"
                                  value={props.translate("SAVE_ADDRESS")}
                                />
                              </center>
                            ) : (
                              <div className="row" id="button_Align">
                                <div className="col-xs-6">
                                  <center>
                                    <input
                                      onClick={() =>
                                        props.handleSaveBillingAddress()
                                      }
                                      type="submit"
                                      style={{
                                        padding: "5px",
                                        backgroundColor: "#1d708a",
                                        color: "white",
                                        width: "100px",
                                        height: "35px",
                                        borderRadius: "25px",
                                        border: "1px solid",
                                      }}
                                      className="field_bt"
                                      value={props.translate("SAVE_ADDRESS")}
                                    />
                                  </center>
                                </div>
                                <div className="col-xs-6">
                                  <center>
                                    <input
                                      onClick={() =>
                                        props.showAddressModal("billing")
                                      }
                                      type="submit"
                                      style={{
                                        padding: "5px",
                                        backgroundColor: "#1d708a",
                                        color: "white",
                                        width: "140px",
                                        height: "35px",
                                        borderRadius: "25px",
                                        border: "1px solid",
                                      }}
                                      className="field_bt"
                                      value={props.translate("CHANGE_ADDRESS")}
                                    />
                                  </center>
                                </div>
                              </div>
                            )}
                          </div>
                          {/*<div className="col-xs-6">
                                         <center>
                                            <input onClick={() => props.showAddressModal('billing')} type="submit" style={{backgroundColor: '#1d708a',color: 'white',width:'140px',height:'35px',borderRadius: '25px',border:'1px solid'}} className="field_bt" value={props.translate('CHANGE_ADDRESS')}/>
                                        </center>
                                      </div>*/}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="row">
                      <div className="col-md-12">
                        <center>
                          <img
                            src={lazyLoader}
                            style={{ height: "60px", width: "60px" }}
                            alt="lazy-loader"
                          />
                        </center>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="col-lg-4 col-md-12">
                <div
                  id="paymt"
                  style={{ border: "1px solid #eaeaea", padding: "20px" }}
                >
                  <div>
                    <div className="row">
                      <div
                        className="col-lg-12 col-md-12 col-xs-12 col-sm-12"
                        id="apply"
                      >
                        <center style={{ marginTop: "10px" }}>
                          <h5
                            style={{
                              color: "black",
                              fontWeight: "500",
                              fontWeight: "bold",
                            }}
                          >
                            {props.translate("MODE_OF_PAYMENT")}
                          </h5>
                        </center>

                        {props.showConsultation === false ? (
                          <div>
                            {props.cartDataShow.totals.grandSub_total !== 0 ? (
                              <div>
                                <div className="radio-box newsletter__radio">
                                  <input
                                    type="radio"
                                    id="online"
                                    name="online"
                                    value="online"
                                    checked={props.modeOfPayment === "online"}
                                    onChange={props.onSiteChangedData}
                                  />
                                  <div className="radio-box__state radio-box__state--primary">
                                    <label
                                      className="radio-box__label"
                                      for="male"
                                    >
                                      {props.translate("ONLINE")}
                                    </label>
                                  </div>
                                </div>

                                <br />
                                <div className="radio-box newsletter__radio">
                                  <input
                                    type="radio"
                                    id="cod"
                                    name="cod"
                                    value="cod"
                                    checked={props.modeOfPayment === "cod"}
                                    onChange={props.onSiteChangedData}
                                  />
                                  <div class="radio-box__state radio-box__state--primary">
                                    <label
                                      className="radio-box__label"
                                      for="female"
                                    >
                                      {props.translate("CASH_ON_DELIVERY")}
                                    </label>
                                  </div>
                                </div>
                              </div>
                            ) : (
                              <div>
                                <centre>
                                  <h4 style={{ marginLeft: "24%" }}>
                                    {" "}
                                    Cash On Delivery
                                  </h4>
                                </centre>
                              </div>
                            )}
                          </div>
                        ) : (
                          <div>
                            <center>
                              <span>{props.translate("ONLINE1")}</span>
                            </center>
                          </div>
                        )}

                        <br />
                        {/* {props.modeOfPayment === 'online' &&   */}
                        <div>
                          <div>
                            <label>{props.translate("APPLY_PROMO_CODE")}</label>
                            <br />
                            <div
                              style={{ display: "flex", marginLeft: "-14px" }}
                            >
                              <input
                                style={{ padding: "10px", width: "180px" }}
                                placeholder={props.translate(
                                  "ENTER_PROMO_CODE"
                                )}
                                id="coupon_code"
                                title="coupon_code"
                                name="coupon_code"
                                value={props.discountCouponValue}
                                onChange={props.handleInputChange}
                              />
                              <span>{props.errors.discountCouponValue}</span>
                              &nbsp;&nbsp;
                              {props.cartDataShow.totals.coupon_code ===
                              null ? (
                                <a
                                  className=" mt-3"
                                  id="applied"
                                  title="Apply Coupon"
                                  onClick={props.applyDiscountCoupon}
                                  value="Apply Coupon"
                                  style={{ cursor: "pointer" }}
                                >
                                  <span>
                                    {props.couponApplied === false ? (
                                      <span className="btn btn--e-brand-b-2">
                                        &nbsp;&nbsp;
                                        {props.translate("APPLY1")}
                                      </span>
                                    ) : (
                                      <span>
                                        <div class="spinner-border btn--icon"></div>
                                      </span>
                                    )}
                                  </span>
                                </a>
                              ) : (
                                <span>
                                  <span
                                    style={{ color: "green", fontSize: "12px" }}
                                  >
                                    &nbsp;&nbsp;(
                                    {props.cartDataShow.totals.coupon_code}{" "}
                                    {props.translate("APPLIED")})
                                  </span>
                                  &nbsp;&nbsp;
                                  <a
                                    className=" mt-3"
                                    title="Remove Coupon"
                                    onClick={props.cancelDiscountCoupon}
                                    value="Remove Coupon"
                                    style={{ cursor: "pointer" }}
                                  >
                                    <span>
                                      {props.cancelCouponApplied === false ? (
                                        <span
                                          className="apply-coupoun-btn"
                                          style={{ color: "f96495" }}
                                        >
                                          &nbsp;&nbsp;&nbsp;&nbsp;
                                          {props.translate("REMOVE1")}
                                        </span>
                                      ) : (
                                        <span>
                                          <div class="spinner-border btn--icon"></div>
                                        </span>
                                      )}
                                    </span>
                                  </a>
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        {/* } */}

                        <br />

                        <div>
                          {props.modeOfPayment === "online" &&
                            props.rewardsAllData !== undefined && (
                              <div className="u-s-m-b-15">
                                {props.rewardsAllData.point_balance !== 0 && (
                                  <div id="parag">
                                    <span style={{ color: "blue" }}>
                                      {props.translate("USE_APP_WALLET")}
                                    </span>
                                    <br />
                                    <p>{props.translate("CHOOSE_WALLET")}</p>
                                    <p>
                                      {props.translate("AMOUNT_IN_WALLET")}{" "}
                                      {props.rewardsAllData.point_balance}{" "}
                                      {props.translate("MAXIMUM")} &#8377; 49
                                    </p>

                                    <div
                                      className="row"
                                      style={{ marginTop: "22px" }}
                                    >
                                      <div className="col-xs-6" id="addamt">
                                        <input
                                          style={{ width: "100px" }}
                                          className="input-counter__text input-counter--text-primary-style"
                                          type="text"
                                          id="rewardStateData"
                                          name="rewardStateData"
                                          value={props.rewardStateData}
                                          onChange={props.handleChangeData}
                                          data-min="1"
                                          data-max="100"
                                        />
                                      </div>
                                      {props.totalAmount !== undefined &&
                                      props.totalAmount.extension_attributes
                                        .use_point === "0" ? (
                                        <div
                                          className="col-xs-6"
                                          id="addam"
                                          style={{ marginTop: "7px" }}
                                        >
                                          {props.rewardsAllData.point_balance >=
                                            "49" ||
                                          props.rewardStateData <= "49" ? (
                                            <div>
                                              {props.rewardsAddLoader ===
                                              false ? (
                                                <a
                                                  className="btn btn--e-brand-b-2"
                                                  onClick={() =>
                                                    props.addRewardsAmount()
                                                  }
                                                >
                                                  {props.translate(
                                                    "ADD_AMOUNT"
                                                  )}
                                                </a>
                                              ) : (
                                                <div class="spinner-border btn--icon"></div>
                                              )}
                                            </div>
                                          ) : (
                                            <div>
                                              {props.rewardsAddLoader ===
                                              false ? (
                                                <a
                                                  className="btn btn--e-brand-b-2"
                                                  disabled
                                                >
                                                  {props.translate(
                                                    "ADD_AMOUNT"
                                                  )}
                                                </a>
                                              ) : (
                                                <div class="spinner-border btn--icon"></div>
                                              )}
                                            </div>
                                          )}
                                        </div>
                                      ) : (
                                        <div
                                          className="col-xs-6"
                                          id="addam"
                                          style={{ marginTop: "7px" }}
                                        >
                                          {props.rewardsAddLoader === false ? (
                                            <a
                                              className="btn btn--e-brand-b-2"
                                              onClick={
                                                props.removeRewardsAmount
                                              }
                                            >
                                              {props.translate("REMOVE_AMOUNT")}
                                            </a>
                                          ) : (
                                            <div class="spinner-border btn--icon"></div>
                                          )}
                                        </div>
                                      )}
                                      {/* <div className="col-md-4"> 
                                                    </div>  */}
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                        </div>
                      </div>
                    </div>

                    <div className="row">
                      {props.priceData !== undefined && (
                        <div className="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                          <div className="row">
                            <div className="col-xs-6">
                              <p style={{ color: "black", fontWeight: "600" }}>
                                {props.translate("SUB_TOTAL")}
                              </p>
                            </div>
                            <div className="col-xs-6">
                              <p style={{ color: "black", fontWeight: "600" }}>
                                &#8377;{props.priceData.totals.subtotal}
                              </p>
                            </div>
                          </div>
                          {props.modeOfPayment === "online" && (
                            <div className="row">
                              <div className="col-xs-6">
                                <p style={{ color: "black" }}>
                                  {props.translate("PROMO_DISCOUNT")}
                                </p>
                              </div>

                              <div className="col-xs-6">
                                <p style={{ color: "black" }}>
                                  {" "}
                                  &#8377;
                                  {props.priceData.totals.discount_amount}
                                </p>
                              </div>
                            </div>
                          )}
                          <div className="row">
                            <div className="col-xs-6">
                              <p style={{ color: "black" }}>
                                {props.translate("WALLET_DISCOUNT")}
                              </p>
                            </div>

                            <div className="col-xs-6">
                              <p style={{ color: "black" }}>
                                - &#8377;
                                {
                                  props.priceData.totals.extension_attributes
                                    .use_point
                                }
                              </p>
                            </div>
                          </div>
                          <div className="row">
                            <div className="col-xs-6">
                              <p style={{ color: "black" }}>
                                {props.translate("SHIPPING_FEES")}
                              </p>
                            </div>
                            <div className="col-xs-6">
                              <p style={{ color: "black" }}>
                                &#8377;{props.priceData.totals.shipping_amount}
                              </p>
                            </div>
                          </div>
                          <div className="row">
                            <div className="col-xs-6">
                              <p style={{ color: "black", fontWeight: "600" }}>
                                {props.translate("GRAND_TOTAL")}
                              </p>
                            </div>
                            <div className="col-xs-6">
                              <p style={{ color: "black", fontWeight: "600" }}>
                                &#8377;
                                {props.priceData.totals.grand_total.toFixed(2)}
                              </p>
                            </div>
                          </div>
                          {/* {props.modeOfPayment === "online" ?
                               <div className="row">
                                    <div className="col-xs-6"><p style={{color:'black',fontWeight:'600'}}>{props.translate('GRAND_TOTAL')}</p></div>
                                    <div className="col-xs-6"><p style={{color:'black',fontWeight:'600'}}>&#8377;{props.onlineGrandTotal.toFixed(2)}</p></div>
                               </div>
                               :
                               <div className="row">
                                    <div className="col-xs-6"><p style={{color:'black',fontWeight:'600'}}>{props.translate('GRAND_TOTAL')}</p></div>
                                    <div className="col-xs-6"><p style={{color:'black',fontWeight:'600'}}>&#8377;{props.codGrandTotal.toFixed(2)}</p></div>
                               </div>
                              } */}
                        </div>
                      )}

                      <br />
                      <div className="row">
                        <div className="col-md-12" id="proceed">
                          <center>
                            {props.checkOutLoader === false ? (
                              <a
                                onClick={() => props.showCheckOut()}
                                type="submit"
                                style={{
                                  cursor: "pointer",
                                  backgroundColor: "rgb(29, 112, 138)",
                                  color: "white",
                                  width: "200px",
                                  height: "45px",
                                  paddingTop: "10px",
                                  borderRadius: "25px",
                                  border: "1px solid",
                                }}
                                className="field_bt"
                              >
                                {props.translate("PROCEED_TO_CHECKOUT")}
                              </a>
                            ) : (
                              <div class="spinner-border btn--icon"></div>
                            )}
                          </center>
                        </div>
                      </div>

                      <br />
                    </div>
                  </div>
                </div>
              </div>

              <br />
            </div>
          </div>
          <br />
          <br />
        </div>

        {props.showAdModal && (
          <Modal
            open={props.showAdModal}
            onClose={() => props.showAddressModalNew()}
          >
            <div className="container width-ad-modal">
              <div className="closeButton">
                <a onClick={props.showAddressModal}>X</a>
              </div>
              <h2 style={{ fontFamily: "Quintessential", fontSize: "23px" }}>
                {props.translate("ALL_ADDRESS")}
              </h2>
              <br />

              <br />
              <div>
                <div className="dash__box dash__box--shadow dash__box--bg-white dash__box--radius u-s-m-b-30">
                  <div className="dash__table-2-wrap gl-scroll">
                    <table className="dash__table-2">
                      <thead>
                        <tr>
                          <th>{props.translate("ACTION")}</th>
                          <th>{props.translate("FULL_NAME")}</th>
                          <th>{props.translate("ADDRESS")}</th>
                          <th>{props.translate("REGION")}</th>
                          <th>{props.translate("PHONE_NUMBER")}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {props.addTerm === "shipping" &&
                          props.allShipDataNew.length !== 0 &&
                          props.allShipDataNew.map((thisAddress, index) => {
                            return (
                              <tr key={index}>
                                <td>
                                  <input
                                    type="radio"
                                    id={index}
                                    name={index}
                                    value={props.addChecked}
                                    checked={
                                      props.addChecked === thisAddress.id
                                    }
                                    onChange={() =>
                                      props.onSiteChanged(thisAddress)
                                    }
                                  />
                                </td>
                                <td>
                                  {thisAddress.firstname}&nbsp;
                                  {thisAddress.lastname}
                                </td>
                                <td>
                                  {thisAddress.street[0]}&nbsp;
                                  {thisAddress.street[1]}
                                </td>
                                <td>
                                  {thisAddress.city}&nbsp;,
                                  {thisAddress.region.region},
                                  {thisAddress.postcode}
                                </td>
                                <td>{thisAddress.telephone}</td>
                              </tr>
                            );
                          })}
                        {props.addTerm === "billing" &&
                          props.allBillDataNew.length !== 0 &&
                          props.allBillDataNew.map((thisAddress, index) => {
                            return (
                              <tr key={index}>
                                <td>
                                  <input
                                    type="radio"
                                    id={index}
                                    name={index}
                                    value={props.addChecked}
                                    checked={
                                      props.addChecked === thisAddress.id
                                    }
                                    onChange={() =>
                                      props.onSiteChanged(thisAddress)
                                    }
                                  />
                                </td>
                                <td>
                                  {thisAddress.firstname}&nbsp;
                                  {thisAddress.lastname}
                                </td>
                                <td>
                                  {thisAddress.street[0]}&nbsp;
                                  {thisAddress.street[1]}
                                </td>
                                <td>
                                  {thisAddress.city}&nbsp;,
                                  {thisAddress.region.region},
                                  {thisAddress.postcode}
                                </td>
                                <td>{thisAddress.telephone}</td>
                              </tr>
                            );
                          })}
                        {/* { props.addAllData.length !== 0 && props.addAllData.map((thisAddress, index) => {
                                                    return (  
                                                    <tr key={index}>
                                                        <td>
                                                        <input type="radio" id={index} name={index} 
                                                            value={props.addChecked} 
                                                            checked={props.addChecked === thisAddress.id} 
                                                            onChange={() => props.onSiteChanged(thisAddress)}
                                                            />
                                                            </td>
                                                        <td>{thisAddress.firstname}&nbsp;{thisAddress.lastname}</td>
                                                        <td>{thisAddress.street[0]}&nbsp;{thisAddress.street[1]}</td>
                                                        <td>{thisAddress.city}&nbsp;,{thisAddress.region.region},{thisAddress.postcode}</td>
                                                        <td>{thisAddress.telephone}</td>
                                                       
                                                    </tr>
                                                 )})}   */}
                      </tbody>
                    </table>
                  </div>
                </div>

                <br />
                <div>
                  {props.addTerm === "shipping" ? (
                    <center>
                      <br />
                      {props.showViewLoader === false ? (
                        <input
                          onClick={() => props.updateChangeAddress()}
                          type="submit"
                          style={{
                            padding: "5px",
                            backgroundColor: "#1d708a",
                            color: "white",
                            width: "200px",
                            height: "45px",
                            borderRadius: "25px",
                            border: "1px solid",
                          }}
                          className="field_bt"
                          value={props.translate("UPDATE_ADDRESS")}
                        />
                      ) : (
                        <div class="spinner-border btn--icon"></div>
                      )}
                    </center>
                  ) : (
                    <center>
                      <br />
                      {props.showViewLoader === false ? (
                        <input
                          onClick={() => props.updateChangeAddressBilling()}
                          type="submit"
                          style={{
                            padding: "5px",
                            backgroundColor: "#1d708a",
                            color: "white",
                            width: "200px",
                            height: "45px",
                            borderRadius: "25px",
                            border: "1px solid",
                          }}
                          className="field_bt"
                          value={props.translate("UPDATE_ADDRESS")}
                        />
                      ) : (
                        <div class="spinner-border btn--icon"></div>
                      )}
                    </center>
                  )}
                </div>
              </div>
            </div>
          </Modal>
        )}
      </div>
    );
  }
  return (
    <div className="cart-empty col-sm-12">
      {props.guestCartData.length !== 0 && props.apiToken === "" ? (
        <div className="container">
          <div style={{ border: "2px solid #eaeaea" }}>
            <div className="row">
              <div className="col-lg-4 col-md-4 col-xs-4 col-sm-4"></div>
              <div className="col-lg-4 col-md-4 col-xs-4 col-sm-4"></div>
              <div className="col-lg-4 col-md-4 col-xs-4 col-sm-4">
                <div className="row" style={{ marginTop: "15px" }}>
                  <div className="col-md-4">
                    <p style={{ color: "black" }}>{props.translate("QTY")}</p>
                  </div>
                  <div className="col-md-4">
                    <p style={{ color: "black" }}>{props.translate("PRICE")}</p>
                  </div>
                  <div className="col-md-4">
                    <p style={{ color: "black" }}>
                      {props.translate("TOTALS")}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {props.guestCartData.map((thisCart, index) => {
              return (
                <div
                  key={index}
                  className="row"
                  style={{ minHeight: "165px" }}
                  key={index}
                >
                  <div className="col-lg-5 col-md-5 col-xs-5 col-sm-5">
                    <React.Fragment>
                      <div>
                        <div className="row">
                          <div className="col-lg-5 col-md-5 col-xs-5 col-sm-5">
                            <div className="row" style={{ marginLeft: "0px" }}>
                              <div
                                className="col-md-2"
                                style={{ marginLeft: "0px", marginTop: "56px" }}
                              >
                                <a
                                  style={{ cursor: "pointer" }}
                                  onClick={() =>
                                    props.removeGuestProduct(thisCart.item_id)
                                  }
                                >
                                  <img
                                    src={circle}
                                    style={{ height: "20px", width: "20px" }}
                                  />
                                </a>
                              </div>
                              <div className="col-md-10">
                                <div
                                  style={{
                                    width: "140px",
                                    height: "140px",
                                    border: "1px solid #eaeaea",
                                  }}
                                >
                                  <img
                                    src={thisCart.image}
                                    style={{ width: "130px", height: "130px" }}
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                          <div
                            className="col-lg-7 col-md-7 col-xs-7 col-sm-7"
                            style={{ marginTop: "30px" }}
                          >
                            <p style={{ color: "black" }}>{thisCart.name}</p>
                            {/*<center>
                                                      <a style={{color:'#8AB77D',cursor:'pointer'}} onClick={() => props.removeProduct(thisCart.item_id)}>(Remove)</a>
                                                   </center>*/}
                            <p style={{ color: "black" }}>
                              Date of Delivery :{" "}
                              {thisCart.custom_attributes.delivery_date}
                            </p>

                            {/* <p className="cart-deli-date">Delivery Date : {moment(thisCart.delivery_date, 'YYYY-MM-DD').format('DD MMM YYYY')}<img className="cart-calendar" src={ calendarImage }></img></p> */}
                            {/* <p className="cart-deli">Delivery Method : {thisCart.delivery_method}</p> 
                                                        <div style={{ cursor: 'pointer' }} onClick={() => props.removeProduct(thisCart.item_id)} title='Remove Item'>Delete</div>*/}
                          </div>
                        </div>
                      </div>
                    </React.Fragment>
                  </div>

                  <div className="col-lg-3 col-md-3 col-xs-3 col-sm-3">
                    <div className="row">
                      <div
                        className="col-md-12"
                        style={{ marginTop: "25px", marginLeft: "-20px" }}
                      >
                        <textarea
                          style={{ padding: "15px" }}
                          placeholder={props.translate("MESSAGE")}
                          rows={2}
                          cols={25}
                        />
                        <br />
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-4 col-md-4 col-xs-4 col-sm-4">
                    <div className="row" style={{ marginTop: "25px" }}>
                      <div className="col-md-4">
                        <p style={{ color: "black" }}>
                          {" "}
                          <div className="cart-info quantity">
                            <div
                              className="btn-increment-decrement"
                              onClick={() =>
                                props.updateGuestCart(
                                  thisCart,
                                  "sub",
                                  thisCart.qty
                                )
                              }
                            >
                              -
                            </div>
                            <input
                              className="input-quantity"
                              id="input-quantity-wristWear03"
                              value={thisCart.qty}
                            />
                            <div
                              className="btn-increment-increment"
                              onClick={() =>
                                props.updateGuestCart(
                                  thisCart,
                                  "add",
                                  thisCart.qty
                                )
                              }
                            >
                              +
                            </div>
                          </div>
                        </p>
                      </div>
                      <div className="col-md-4">
                        <p style={{ color: "black" }}>{thisCart.price}</p>
                      </div>
                      <div className="col-md-4">
                        <p style={{ color: "black" }}>{thisCart.row_total}</p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
            <div>
              <div className="row">
                <div className="col-lg-4 col-md-4 col-xs-4 col-sm-4"></div>
                <div className="col-lg-4 col-md-4 col-xs-4 col-sm-4"></div>
                <div className="col-lg-4 col-md-4 col-xs-4 col-sm-4">
                  <div className="row">
                    <div className="col-md-4">
                      <p style={{ color: "black", fontWeight: "600" }}>
                        {props.translate("SUB_TOTAL")}
                      </p>
                    </div>
                    <div className="col-md-4"></div>
                    <div className="col-md-4">
                      <p style={{ color: "black", fontWeight: "600" }}>
                        {props.guestList[0].totals.subtotal}
                      </p>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-4">
                      <p style={{ color: "black" }}>
                        {props.translate("DISCOUNT")}
                      </p>
                    </div>
                    <div className="col-md-4"></div>
                    <div className="col-md-4">
                      <p style={{ color: "black" }}>
                        {props.guestList[0].totals.discount}
                      </p>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-4">
                      <p style={{ color: "black" }}>
                        {props.translate("SHIPPING_FEES")}
                      </p>
                    </div>
                    <div className="col-md-4"></div>
                    <div className="col-md-4">
                      <p style={{ color: "black" }}>
                        {props.guestList[0].totals.shipping_amount}
                      </p>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-4">
                      <p style={{ color: "black", fontWeight: "600" }}>
                        {props.translate("GRAND_TOTAL")}
                      </p>
                    </div>
                    <div className="col-md-4"></div>
                    <div className="col-md-4">
                      <p style={{ color: "black", fontWeight: "600" }}>
                        {props.guestList[0].totals.grand_total}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <br />
            <br />
          </div>

          <br />
          <div>
            <div className="row">
              <div className="col-md-12">
                <center>
                  <button
                    type="button"
                    style={{
                      height: "60px",
                      width: "250px",
                      backgroundColor: "#1d708a",
                      border: "1px solid",
                      borderRadius: "35px",
                      color: "white",
                    }}
                    className=""
                    onClick={props.showWithoutLogin}
                  >
                    {props.translate("PLEASE_LOGIN_TO_PLACE_YOUR_ORDER")}
                  </button>
                </center>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div style={{ paddingTop: "100px" }}>
          <center>
            <div className="page-title">
              <h1>{props.translate("SHOPPING_CART_IS_EMPTY")}</h1>
              <br />
              <button
                onClick={props.contShop}
                style={{
                  height: "50px",
                  width: "141px",
                  backgroundColor: "#1d708a",
                  border: "1px solid",
                  borderRadius: "20px",
                  color: "white",
                }}
              >
                {props.translate("CLICK")} {props.translate("HERE")}
              </button>
              {/* <h5>{props.translate('TO_CONTINUE_SHOPPING')}</h5> */}
            </div>
            {/* <div className="no-cart-empty">
                            <p>{props.translate('SHOPPING_CART_IS_EMPTY')}</p>
                            <p>{props.translate('CLICK')} <a href="/">{props.translate('HERE')}</a> {props.translate('TO_CONTINUE_SHOPPING')}</p>
                            <a class="empty__redirect-link btn--e-brand" href="/"><i class="fas fa-plus u-s-m-r-8"></i>
                             <span>{props.translate('ADD_PRODUCT')}</span></a>   
                        </div> */}
          </center>
          <br />
          <br />
          <br />
        </div>
      )}
      <br />
      <br />
    </div>
  );
}
