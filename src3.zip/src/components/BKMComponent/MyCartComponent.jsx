import React from 'react';
import Button from 'react-bootstrap/lib/Button';
import _get from 'lodash/get';
import { FormComponent, FormContainer } from "react-authorize-net";
import moment from 'moment';
import AliceCarousel from 'react-alice-carousel';
import 'react-alice-carousel/lib/alice-carousel.css';
import { useMediaQuery } from 'react-responsive';
import MaModal from '../Common/MaterialUIModal.jsx';
// import { Slider, InputNumber } from 'antd';
import calendarImage from '../../assets/images/select-date.png';
import lazyLoader from '../../assets/img/25.gif';
import circle from '../../assets/img/circle.svg';
import Image from 'react-image-resizer';
import { defaultMergeProps } from 'react-redux/lib/connect/mergeProps';


export default function MyCartComponent(props) {
  console.log(props);
  let result = [];
  let address = undefined;
  const Desktop = ({ children }) => {
    const isDesktop = useMediaQuery({ minWidth: 992 })
    return isDesktop ? children : null
  }
  const Tablet = ({ children }) => {
    const isTablet = useMediaQuery({ minWidth: 768, maxWidth: 991 })
    return isTablet ? children : null
  }
  const Mobile = ({ children }) => {
    const isMobile = useMediaQuery({ maxWidth: 767 })
    return isMobile ? children : null
  }
  // if (props.customerAddress.length !== 0) {
  //   for (var i = 0; i < props.customerAddress.length; i++) {
  //     if (props.customerAddress[i].default_shipping === true) {
  //       address = props.customerAddress[i];
  //     }
  //   }
  // }
  if (props.totalCartItems.length !== 0) {
    return (
      <div>



        <div className="" style={{ marginTop: '40px' }}>

          <div className="section__intro u-s-m-b-60">
            <div className="container">
              <div className="row">
                <div className="col-lg-12">
                  <div className="section__text-wrap">
                    <h1 className="section__heading u-c-secondary" style={{ color: '#4B817B' }}>CHECKOUT</h1>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <Desktop>
            <div className="section__content">
              <div className="container">
                <div className="row">
                  <div className="col-lg-12 col-md-12 col-sm-12 u-s-m-b-10px">
                    <div className="table-responsive">
                      <table class="table-p">
                        <tbody>


                          {props.totalCartItems.map((thisCart, index) => {
                            return (
                              <tr key={index} >
                                <td>
                                  <div className="table-p__box">
                                    <div className="table-p__info">
                                      <a onClick={() => props.removeProduct(thisCart.item_id)}><i class="far fa-times-circle" style={{ fontSize: '25px', color: '#A87048' }}></i></a>
                                    </div>
                                    <div style={{ border: '1px solid #CCCCCC', marginLeft: '10px' }}>
                                      <Image src={thisCart.image} width={150}
                                        height={200} />


                                    </div>
                                    <div className="table-p__info" style={{ marginTop: '-33px' }}>

                                      <span className="table-p__name">

                                        <a style={{ fontSize: '20px', lineHeight: '29px' }}>{thisCart.name}</a></span>

                                      <ul className="table-p__variant-list">
                                        <li className="margin-table">

                                          <span style={{ fontSize: '16px', color: 'black' }}><b>Size</b>: {
                                            thisCart.sku.split("-").pop()
                                          }</span>
                                        </li>
                                        {/* <li className="margin-table">

                                          <span style={{ fontSize: '16px', color: 'black' }}><b>Recipient</b>: {props.fullName}</span>
                                        </li> */}
                                        {props.shippingAddressData !== undefined &&
                                          <li className="margin-table">

                                            <span style={{ fontSize: '16px', color: 'black' }}><b>Delivery Address</b>: {props.shippingAddressData.street[0]} {props.shippingAddressData.city} , {props.shippingAddressData.region.region_code} {props.shippingAddressData.postcode}</span>
                                          </li>
                                        }
                                        <li className="margin-table">

                                          <span style={{ fontSize: '16px', color: 'black' }}><b>Delivery Date</b>: {moment(thisCart.custom_attributes.delivery_date).format('MM/DD/YYYY')}</span>
                                        </li>
                                        <li className="margin-table">

                                          <span style={{ fontSize: '16px', color: 'black' }}><b>Message</b>: {thisCart.custom_attributes.gift_message}</span>
                                        </li>
                                        <li className="margin-table">
                                          <a onClick={() => props.openEditPopUp(thisCart)}><span style={{ color: '#4B817B', textDecoration: 'underline' }}><i class="fas fa-edit" style={{ fontSize: '14px' }}></i> Edit</span></a>

                                        </li>

                                      </ul>
                                    </div>
                                  </div>
                                </td>

                                <td>

                                  <center> <b style={{ color: 'black' }}>Quantity</b>
                                    <br />
                                    <div className="table-p__input-counter-wrap">


                                      <div className="input-counter">

                                        <a onClick={() => props.updateCart(thisCart, 'sub', thisCart.qty)}><span className="input-counter__minus fas fa-minus"></span></a>

                                        <input className="input-counter__text input-counter--text-primary-style" type="text" value={thisCart.qty} data-min="1" data-max="1000" />

                                        <a onClick={() => props.updateCart(thisCart, 'add', thisCart.qty)}><span className="input-counter__plus fas fa-plus"></span></a>
                                      </div>

                                    </div>
                                  </center>
                                </td>
                                <td>
                                  <center> <b style={{ color: 'black' }}>Price</b>
                                    <br />
                                    <span className="table-p__price">&#8377;{thisCart.price}</span>
                                  </center>
                                </td>
                                <td>
                                  <center> <b style={{ color: 'black' }}>Total</b>
                                    <br />
                                    <span className="table-p__price">&#8377;{thisCart.row_total}</span>
                                  </center>
                                </td>
                              </tr>
                            )
                          })}



                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              </div>
            </div>

          </Desktop>


          <Tablet>
            <div className="section__content">
              <div className="container">
                <div className="row">
                  <div className="col-lg-12 col-md-12 col-sm-12 u-s-m-b-10px">
                    <div className="table-responsive">
                      <table class="table-p">
                        <tbody>


                          {props.totalCartItems.map((thisCart, index) => {
                            return (
                              <tr key={index} >
                                <td>
                                  <div className="table-p__box">
                                    <div className="table-p__info">
                                      <a onClick={() => props.removeProduct(thisCart.item_id)}><i class="far fa-times-circle" style={{ fontSize: '25px', color: '#A87048' }}></i></a>
                                    </div>
                                    <div style={{ border: '1px solid #CCCCCC', marginLeft: '10px' }}>
                                      <Image src={thisCart.image} width={150}
                                        height={200} />


                                    </div>
                                    <div className="table-p__info" style={{ marginTop: '-33px' }}>

                                      <span className="table-p__name">

                                        <a style={{ fontSize: '20px', lineHeight: '29px' }}>{thisCart.name}</a></span>

                                      <ul className="table-p__variant-list">
                                        <li className="margin-table">

                                          <span style={{ fontSize: '16px', color: 'black' }}><b>Size</b>: {thisCart.product_type === 'simple' ? 'Simple' : thisCart.product_type}</span>
                                        </li>
                                        <li className="margin-table">

                                          <span style={{ fontSize: '16px', color: 'black' }}><b>Recipient</b>: {props.fullName}</span>
                                        </li>
                                        {props.shippingAddressData !== undefined &&
                                          <li className="margin-table">

                                            <span style={{ fontSize: '16px', color: 'black' }}><b>Delivery Address</b>: {props.shippingAddressData.street[0]} {props.shippingAddressData.city} , {props.shippingAddressData.region.region_code} {props.shippingAddressData.postcode}</span>
                                          </li>
                                        }
                                        <li className="margin-table">

                                          <span style={{ fontSize: '16px', color: 'black' }}><b>Delivery Date</b>: {moment(thisCart.custom_attributes.delivery_date).format('MM/DD/YYYY')}</span>
                                        </li>
                                        <li className="margin-table">

                                          <span style={{ fontSize: '16px', color: 'black' }}><b>Message</b>: {thisCart.custom_attributes.gift_message}</span>
                                        </li>
                                        <li className="margin-table">
                                          <a onClick={() => props.openEditPopUp(thisCart)}><span style={{ color: '#4B817B', textDecoration: 'underline' }}><i class="fas fa-edit" style={{ fontSize: '14px' }}></i> Edit</span></a>

                                        </li>

                                      </ul>
                                    </div>
                                  </div>
                                </td>

                                <td>

                                  <center> <b style={{ color: 'black' }}>Quantity</b>
                                    <br />
                                    <div className="table-p__input-counter-wrap">


                                      <div className="input-counter">

                                        <a onClick={() => props.updateCart(thisCart, 'sub', thisCart.qty)}><span className="input-counter__minus fas fa-minus"></span></a>

                                        <input className="input-counter__text input-counter--text-primary-style" type="text" value={thisCart.qty} data-min="1" data-max="1000" />

                                        <a onClick={() => props.updateCart(thisCart, 'add', thisCart.qty)}><span className="input-counter__plus fas fa-plus"></span></a>
                                      </div>

                                    </div>
                                  </center>
                                </td>
                                <td>
                                  <center> <b style={{ color: 'black' }}>Price</b>
                                    <br />
                                    <span className="table-p__price">&#8377;{thisCart.price}</span>
                                  </center>
                                </td>
                                <td>
                                  <center> <b style={{ color: 'black' }}>Total</b>
                                    <br />
                                    <span className="table-p__price">&#8377;{thisCart.row_total}</span>
                                  </center>
                                </td>
                              </tr>
                            )
                          })}



                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              </div>
            </div>

          </Tablet>



          <Mobile>
            <div className="section__content">
              <div className="container">
                <div className="row">
                  <div className="col-lg-12 col-md-12 col-sm-12 u-s-m-b-10px">
                    <div className="">
                      {props.totalCartItems.map((thisCart, index) => {
                        return (
                          <div key={index}>
                            <hr style={{ width: '100%' }} />
                            <div className="row">
                              <div className="col-lg-12">
                                <a onClick={() => props.removeProduct(thisCart.item_id)}><i class="far fa-times-circle" style={{ fontSize: '25px', color: '#A87048', float: 'right' }}></i></a>
                              </div>
                            </div>


                            <tr>
                              <td>
                                <div className="table-p__box">

                                  <div style={{ border: '1px solid #CCCCCC', marginLeft: '10px', marginTop: '-78px' }}>
                                    <Image src={thisCart.image} width={90}
                                      height={110} />


                                  </div>
                                  <div className="table-p__info">

                                    <span className="table-p__name">

                                      <a style={{ fontSize: '20px', lineHeight: '29px' }}>{thisCart.name}</a></span>

                                    <ul className="table-p__variant-list">
                                      <li className="margin-table">

                                        <span style={{ fontSize: '16px', color: 'black' }}><b>Size</b>: {thisCart.product_type === 'simple' ? 'Simple' : thisCart.product_type}</span>
                                      </li>
                                      <li className="margin-table">

                                        <span style={{ fontSize: '16px', color: 'black' }}><b>Recipient</b>: {props.fullName}</span>
                                      </li>
                                      {props.shippingAddressData !== undefined &&
                                        <li className="margin-table">

                                          <span style={{ fontSize: '16px', color: 'black' }}><b>Delivery Address</b>: {props.shippingAddressData.street[0]} {props.shippingAddressData.city} ,{props.shippingAddressData.region.region_code} {props.shippingAddressData.postcode}</span>
                                        </li>
                                      }
                                      <li className="margin-table">

                                        <span style={{ fontSize: '16px', color: 'black' }}><b>Delivery Date</b>: {moment(thisCart.custom_attributes.delivery_date).format('MM/DD/YYYY')}</span>
                                      </li>
                                      <li className="margin-table">

                                        <span style={{ fontSize: '16px', color: 'black' }}><b>Message</b>: {thisCart.custom_attributes.gift_message}</span>
                                      </li>
                                      <li className="margin-table">
                                        <a onClick={() => props.openEditPopUp(thisCart)}><span style={{ color: '#4B817B', textDecoration: 'underline' }}><i class="fas fa-edit" style={{ fontSize: '14px' }}></i> Edit</span></a>

                                      </li>

                                    </ul>
                                  </div>
                                </div>
                              </td>
                            </tr>


                            <table style={{ width: '100%' }}>
                              <tbody>



                                <tr>

                                  <td>

                                    <center> <b style={{ color: 'black' }}>Quantity</b>
                                      <br />
                                      <div className="table-p__input-counter-wrap">


                                        <div className="input-counter">

                                          <a onClick={() => props.updateCart(thisCart, 'sub', thisCart.qty)}><span className="input-counter__minus fas fa-minus"></span></a>

                                          <input className="input-counter__text input-counter--text-primary-style" type="text" value={thisCart.qty} data-min="1" data-max="1000" />

                                          <a onClick={() => props.updateCart(thisCart, 'add', thisCart.qty)}><span className="input-counter__plus fas fa-plus"></span></a>
                                        </div>

                                      </div>
                                    </center>
                                  </td>
                                  <td>
                                    <center> <b style={{ color: 'black' }}>Price</b>
                                      <br />
                                      <span className="table-p__price">&#8377;{thisCart.price}</span>
                                    </center>
                                  </td>
                                  <td>
                                    <center> <b style={{ color: 'black' }}>Total</b>
                                      <br />
                                      <span className="table-p__price">&#8377;{thisCart.row_total}</span>
                                    </center>
                                  </td>
                                </tr>
                              </tbody>
                            </table>


                          </div>
                        )
                      })}
                    </div>
                  </div>

                </div>
              </div>
            </div>

          </Mobile>





        </div>
        <Mobile>
          <hr style={{ width: '100%' }} />
        </Mobile>
        <br />
        <div className="section__content">
          <div className="container">
            <div className="row">
              <div className="col-lg-4 col-md-4 col-sm-4 u-s-m-b-10px">

              </div>
              <div className="col-lg-4 col-md-4 col-sm-4 u-s-m-b-10px">

              </div>
              <div className="col-lg-4 col-md-4 col-sm-4 u-s-m-b-10px">

                <div class="u-s-m-b-30">
                  <div class="">
                    <table class="o-summary__table">
                      <tbody>
                        <tr>
                          <td style={{ color: 'rgba(0, 0, 0, 0.6)', fontSize: '12px' }}>Shipping and taxes calculated<br />next when placing your order</td>
                          <td><b style={{ color: 'black', fontSize: '12px' }}>Subtotal</b>
                            <br /><span style={{ color: 'rgba(0, 0, 0, 0.6)', fontSize: '12px' }}>&#x0024;{props.cartDataShow.totals.grand_total}</span></td>
                        </tr>

                      </tbody>
                    </table>
                  </div>
                </div>
                <div>

                  <button style={{ width: '100%', borderRadius: '0px' }} class="btn btn--e-brand-b-2" type="submit" onClick={props.moveToPayment}>PLACE ORDER</button>
                </div>


              </div>
            </div>
          </div>
        </div>






      </div>
    );
  }
  return (

    <div className="cart-empty col-sm-12">
      {props.guestCartData.length !== 0 && props.apiToken === '' ?

        <div className="container">

          <div className="">
            <div className="section__content">
              <div className="container">
                <div className="breadcrumb">
                  <div className="breadcrumb__wrap">
                    <ul className="breadcrumb__list">
                      <li className="has-separator">

                        <a href="/">Home</a></li>
                      <li className="is-marked">

                        <a>Cart</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <div className="" style={{ marginTop: '40px' }}>

            <div className="section__intro u-s-m-b-60">
              <div className="container">
                <div className="row">
                  <div className="col-lg-12">
                    <div className="section__text-wrap">
                      <h1 className="section__heading u-c-secondary">SHOPPING CART</h1>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <Desktop>
              <div className="section__content">
                <div className="container">
                  <div className="row">
                    <div className="col-lg-12 col-md-12 col-sm-12 u-s-m-b-10px">
                      <div className="table-responsive">
                        <table class="table-p">
                          <tbody>


                            {props.guestCartData.map((thisCart, index) => {
                              return (
                                <tr key={index} >
                                  <td>
                                    <div className="table-p__box">
                                      <div className="table-p__info">
                                        <a onClick={() => props.removeGuestProduct(thisCart.item_id)}><i class="far fa-times-circle" style={{ fontSize: '25px', color: '#A87048' }}></i></a>
                                      </div>
                                      <div style={{ border: '1px solid #CCCCCC', marginLeft: '10px' }}>
                                        <Image src={thisCart.image} width={150}
                                          height={200} />


                                      </div>
                                      <div className="table-p__info" style={{ marginTop: '-10px' }}>

                                        <span className="table-p__name">

                                          <a style={{ fontSize: '20px', lineHeight: '29px' }}>{thisCart.name}</a></span>

                                        <ul className="table-p__variant-list">
                                          <li className="margin-table">

                                            <span style={{ fontSize: '16px', color: 'black' }}><b>Size</b>: {
                                              thisCart.sku.split("-").pop()
                                            } </span>
                                          </li>
                                          {/* <li className="margin-table">

                                            <span style={{ fontSize: '16px', color: 'black' }}><b>Recipient</b>: {props.fullName}</span>
                                          </li> */}
                                          {/* <li className="margin-table">

                                            <span style={{ fontSize: '16px', color: 'black' }}><b>Delivery Address</b>: {props.addressData.street[0]} {props.addressData.city}, {props.stateRegionData} {props.addressData.postcode}</span>
                                          </li> */}
                                          <li className="margin-table">

                                            <span style={{ fontSize: '16px', color: 'black' }}><b>Delivery Date</b>: {moment(thisCart.custom_attributes.delivery_date).format('MM/DD/YYYY')}</span>
                                          </li>
                                          <li className="margin-table">

                                            <span style={{ fontSize: '16px', color: 'black' }}><b>Message</b>: {thisCart.custom_attributes.gift_message}</span>
                                          </li>
                                          <li className="margin-table">
                                            <a onClick={() => props.openEditPopUp(thisCart)}><span style={{ color: '#A87048', textDecoration: 'underline' }}><i class="fas fa-edit" style={{ fontSize: '14px' }}></i> Edit</span></a>

                                          </li>

                                        </ul>
                                      </div>
                                    </div>
                                  </td>

                                  <td>

                                    <center> <b style={{ color: 'black' }}>Quantity</b>
                                      <br />
                                      <div className="table-p__input-counter-wrap">


                                        <div className="input-counter">

                                          <a onClick={() => props.updateGuestCart(thisCart, 'sub', thisCart.qty)}><span className="input-counter__minus fas fa-minus"></span></a>

                                          <input className="input-counter__text input-counter--text-primary-style" type="text" value={thisCart.qty} data-min="1" data-max="1000" />

                                          <a onClick={() => props.updateGuestCart(thisCart, 'add', thisCart.qty)}><span className="input-counter__plus fas fa-plus"></span></a>
                                        </div>

                                      </div>
                                    </center>
                                  </td>
                                  <td>
                                    <center> <b style={{ color: 'black' }}>Price</b>
                                      <br />
                                      <span className="table-p__price">&#8377;{thisCart.price}</span>
                                    </center>
                                  </td>
                                  <td>
                                    <center> <b style={{ color: 'black' }}>Total</b>
                                      <br />
                                      <span className="table-p__price">&#8377;{thisCart.row_total}</span>
                                    </center>
                                  </td>
                                </tr>
                              )
                            })}





                          </tbody>
                        </table>
                      </div>
                    </div>






                  </div>
                </div>
              </div>
            </Desktop>
            <Tablet>
              <div className="section__content">
                <div className="container">
                  <div className="row">
                    <div className="col-lg-12 col-md-12 col-sm-12 u-s-m-b-10px">
                      <div className="table-responsive">
                        <table class="table-p">
                          <tbody>


                            {props.guestCartData.map((thisCart, index) => {
                              return (
                                <tr key={index} >
                                  <td>
                                    <div className="table-p__box">
                                      <div className="table-p__info">
                                        <a onClick={() => props.removeGuestProduct(thisCart.item_id)}><i class="far fa-times-circle" style={{ fontSize: '25px', color: '#A87048' }}></i></a>
                                      </div>
                                      <div style={{ border: '1px solid #CCCCCC', marginLeft: '10px' }}>
                                        <Image src={thisCart.image} width={150}
                                          height={200} />


                                      </div>
                                      <div className="table-p__info" style={{ marginTop: '-10px' }}>

                                        <span className="table-p__name">

                                          <a style={{ fontSize: '20px', lineHeight: '29px' }}>{thisCart.name}</a></span>

                                        <ul className="table-p__variant-list">
                                          <li className="margin-table">

                                            <span style={{ fontSize: '16px', color: 'black' }}><b>Size</b>: {thisCart.product_type === 'simple' ? 'Simple' : thisCart.product_type}</span>
                                          </li>
                                          <li className="margin-table">

                                            <span style={{ fontSize: '16px', color: 'black' }}><b>Recipient</b>: {props.fullName}</span>
                                          </li>
                                          {/* <li className="margin-table">

                                            <span style={{ fontSize: '16px', color: 'black' }}><b>Delivery Address</b>: {props.addressData.street[0]} {props.addressData.city} ,{props.stateRegionData} {props.addressData.postcode}</span>
                                          </li> */}
                                          <li className="margin-table">

                                            <span style={{ fontSize: '16px', color: 'black' }}><b>Delivery Date</b>: {moment(thisCart.custom_attributes.delivery_date).format('MM/DD/YYYY')}</span>
                                          </li>
                                          <li className="margin-table">

                                            <span style={{ fontSize: '16px', color: 'black' }}><b>Message</b>: {thisCart.custom_attributes.gift_message}</span>
                                          </li>
                                          <li className="margin-table">
                                            <a onClick={() => props.openEditPopUp(thisCart)}><span style={{ color: '#4B817B', textDecoration: 'underline' }}><i class="fas fa-edit" style={{ fontSize: '14px' }}></i> Edit</span></a>

                                          </li>

                                        </ul>
                                      </div>
                                    </div>
                                  </td>

                                  <td>

                                    <center> <b style={{ color: 'black' }}>Quantity</b>
                                      <br />
                                      <div className="table-p__input-counter-wrap">


                                        <div className="input-counter">

                                          <a onClick={() => props.updateGuestCart(thisCart, 'sub', thisCart.qty)}><span className="input-counter__minus fas fa-minus"></span></a>

                                          <input className="input-counter__text input-counter--text-primary-style" type="text" value={thisCart.qty} data-min="1" data-max="1000" />

                                          <a onClick={() => props.updateGuestCart(thisCart, 'add', thisCart.qty)}><span className="input-counter__plus fas fa-plus"></span></a>
                                        </div>

                                      </div>
                                    </center>
                                  </td>
                                  <td>
                                    <center> <b style={{ color: 'black' }}>Price</b>
                                      <br />
                                      <span className="table-p__price">&#8377;{thisCart.price}</span>
                                    </center>
                                  </td>
                                  <td>
                                    <center> <b style={{ color: 'black' }}>Total</b>
                                      <br />
                                      <span className="table-p__price">&#8377;{thisCart.row_total}</span>
                                    </center>
                                  </td>
                                </tr>
                              )
                            })}





                          </tbody>
                        </table>
                      </div>
                    </div>






                  </div>
                </div>
              </div>
            </Tablet>
            <Mobile>
              <div className="section__content">
                <div className="container">
                  <div className="row">
                    <div className="col-lg-12 col-md-12 col-sm-12 u-s-m-b-10px">
                      <div className="">

                        {props.guestCartData.map((thisCart, index) => {
                          return (
                            <div key={index}>
                              <hr style={{ width: '100%' }} />
                              <div className="row">
                                <div className="col-lg-12">
                                  <a onClick={() => props.removeGuestProduct(thisCart.item_id)}><i class="far fa-times-circle" style={{ fontSize: '25px', color: '#A87048', float: 'right' }}></i></a>
                                </div>
                              </div>


                              <tr>
                                <td>
                                  <div className="table-p__box">

                                    <div style={{ border: '1px solid #CCCCCC', marginLeft: '10px', marginTop: '-78px' }}>
                                      <Image src={thisCart.image} width={90}
                                        height={110} />


                                    </div>
                                    <div className="table-p__info">

                                      <span className="table-p__name">

                                        <a style={{ fontSize: '20px', lineHeight: '29px' }}>{thisCart.name}</a></span>

                                      <ul className="table-p__variant-list">
                                        <li className="margin-table">

                                          <span style={{ fontSize: '16px', color: 'black' }}><b>Size</b>: {thisCart.product_type === 'simple' ? 'Simple' : thisCart.product_type}</span>
                                        </li>
                                        {/* <li className="margin-table">

                                          <span style={{ fontSize: '16px', color: 'black' }}><b>Recipient</b>: {props.fullName}</span>
                                        </li> */}
                                        {/* <li className="margin-table">

                                          <span style={{ fontSize: '16px', color: 'black' }}><b>Delivery Address</b>: {props.addressData.street[0]} {props.addressData.city} ,{props.stateRegionData} {props.addressData.postcode}</span>
                                        </li> */}
                                        <li className="margin-table">

                                          <span style={{ fontSize: '16px', color: 'black' }}><b>Delivery Date</b>: {moment(thisCart.custom_attributes.delivery_date).format('MM/DD/YYYY')}</span>
                                        </li>
                                        <li className="margin-table">

                                          <span style={{ fontSize: '16px', color: 'black' }}><b>Message</b>: {thisCart.custom_attributes.gift_message}</span>
                                        </li>
                                        <li className="margin-table">
                                          <a onClick={() => props.openEditPopUp(thisCart)}><span style={{ color: '#4B817B', textDecoration: 'underline' }}><i class="fas fa-edit" style={{ fontSize: '14px' }}></i> Edit</span></a>

                                        </li>

                                      </ul>
                                    </div>
                                  </div>
                                </td>
                              </tr>


                              <table style={{ width: '100%' }}>
                                <tbody>



                                  <tr>

                                    <td>

                                      <center> <b style={{ color: 'black' }}>Quantity</b>
                                        <br />
                                        <div className="table-p__input-counter-wrap">


                                          <div className="input-counter">

                                            <a onClick={() => props.updateGuestCart(thisCart, 'sub', thisCart.qty)}><span className="input-counter__minus fas fa-minus"></span></a>

                                            <input className="input-counter__text input-counter--text-primary-style" type="text" value={thisCart.qty} data-min="1" data-max="1000" />

                                            <a onClick={() => props.updateGuestCart(thisCart, 'add', thisCart.qty)}><span className="input-counter__plus fas fa-plus"></span></a>
                                          </div>

                                        </div>
                                      </center>
                                    </td>
                                    <td>
                                      <center> <b style={{ color: 'black' }}>Price</b>
                                        <br />
                                        <span className="table-p__price">&#8377;{thisCart.price}</span>
                                      </center>
                                    </td>
                                    <td>
                                      <center> <b style={{ color: 'black' }}>Total</b>
                                        <br />
                                        <span className="table-p__price">&#8377;{thisCart.row_total}</span>
                                      </center>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>


                            </div>
                          )
                        })}

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Mobile>





          </div>






          <Mobile>
            <hr style={{ width: '100%' }} />
          </Mobile>


          <div>






            <div >

              {/* <div class="u-s-m-b-30">
                      <div class="">
                        <table class="o-summary__table">
                          <tbody>
                            <tr>
                              <td style={{ color: 'rgba(0, 0, 0, 0.6)', fontSize: '12px' }}>Shipping and taxes calculated<br />next when placing your order</td>
                              <td><b style={{ color: 'black', fontSize: '12px' }}>Subtotal</b>
                                <br /><span style={{ color: 'rgba(0, 0, 0, 0.6)', fontSize: '12px' }}>&#x0024;{props.guestStateList[0].totals.grand_total}</span></td>
                            </tr>

                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div>

                      <button style={{ width: '100%', borderRadius: '0px' }} class="btn btn--e-brand-b-2" type="submit" onClick={props.showWithoutLogin}>PLACE ORDER</button>
                    </div> */}
              <div className="buttn" id="lg_od">
                <div className="row" id="btn_roow5">
                  <div className="col-md-12">
                    <center>
                      <button
                        type="button"
                        style={{
                          height: "60px",
                          width: "250px",
                          backgroundColor: "#A87048",
                          border: "1px solid #BFC9CA",
                          borderRadius: "35px",
                          color: "white",
                          marginBottom: "100px",
                          marginTop: "25px",
                          fontWeight: "500",
                        }}
                        className="plorder"
                        onClick={props.showWithoutLogin}
                      >
                        Please login to place your Order
                      </button>
                    </center>
                  </div>
                </div>
              </div>


            </div>




          </div>


        </div>


        :
        <div >
          <center>
            <div className="page-title">
              <h1>Shopping Cart is Empty</h1>
            </div>
            <div className="no-cart-empty">
              <p>You have no items in your shopping cart.</p>
              <p>Click <a href="/">here</a> to continue shopping.</p>
            </div>
          </center>
          <br /><br /><br />
        </div>

      }
      <br /><br />
    </div >
  );
}
