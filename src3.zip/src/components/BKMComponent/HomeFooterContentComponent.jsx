import React from 'react';

const homeFooterContentComponent = () => (
        <div className="hp-footer-content">
         
        </div>
    );
    
export default homeFooterContentComponent;
