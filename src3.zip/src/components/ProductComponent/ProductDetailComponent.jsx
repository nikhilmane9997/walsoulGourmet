import React from 'react';
import _get from 'lodash/get';
import _isEmpty from 'lodash/isEmpty';
import StarRatings from 'react-star-ratings';
import ReactImageZoom from 'react-image-zoom';
import SimpleImageSlider from "react-simple-image-slider";
import {
  ButtonBack,
  ButtonFirst,
  ButtonLast,
  ButtonNext,
  CarouselProvider,
  Slide,
  Slider,
  ImageWithZoom,
  Dot,
  DotGroup,
} from 'pure-react-carousel';
import s from 'pure-react-carousel/dist/react-carousel.es.css';
import Zoom from 'react-img-zoom';
import Image from 'react-image-resizer';
import DayPicker from 'react-day-picker';
import 'react-day-picker/lib/style.css';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import moment from 'moment';
import Datetime from 'react-datetime';
import Tabs from 'react-bootstrap/lib/Tabs';
import Tab from 'react-bootstrap/lib/Tab';
import Modal from 'react-bootstrap/lib/Modal';
import Button from 'react-bootstrap/lib/Button';
import MetaTags from 'react-meta-tags';
import AliceCarousel from 'react-alice-carousel';
import 'react-alice-carousel/lib/alice-carousel.css';
import '../../assets/stylesheets/DatePickerReact.css';
import MaModal from '../Common/MaterialUIModal.jsx';
import MaModalOne from '../Common/MaterialUIModalOne.jsx';
import ReviewComponent from '../ProductComponent/reviewComponent.jsx';
import lazyLoader from '../../assets/img/25.gif';
import logo from '../../assets/img/logo.png';
import { configConsumerProps } from 'antd/lib/config-provider';

export default function ProductDetailComponent(props) {
  console.log(props);

  if (props.productDetails) {
    return (
      <div>

        {/*====== Section 1 ======-->*/}
        <div className="u-s-p-t-90">
          <div style={{ marginLeft: '25px', marginRight: '45px' }}>
            <div className="row">
              <div className="col-lg-7">

                {/*====== Product Breadcrumb ======-->*/}
                <div className="pd-breadcrumb u-s-m-b-30 crumb30">
                  <ul className="pd-breadcrumb__list">
                    <li className="has-separator">

                      <a href="/">Home</a></li>

                    <li className="is-marked">

                      <a>{props.productDetails.name}</a></li>
                  </ul>
                </div>
                {/*======  End - Product Breadcrumb ======-->*/}


                {/*======  Product Detail Zoom ======-->*/}

                {/*<CarouselProvider
            visibleSlides={2}
            totalSlides={2}
            //step={1}
            naturalSlideWidth={450}
            naturalSlideHeight={600}
            hasMasterSpinner={true}
        > 
    <div dir="ltr">
      <Slider className={s.slider}>
        <Slide index={0}>
          <ImageWithZoom src={props.productDetails.images[0]} />
        </Slide>
        <Slide index={1}>
          <ImageWithZoom src={props.productDetails.images[1]} />
        </Slide>
        <br/>
        <Slide index={2}>
          <ImageWithZoom src={props.productDetails.images[2]} />
        </Slide>
        <Slide index={3}>
          <ImageWithZoom src={props.productDetails.images[3]} />
        </Slide>
        <br/>
        <Slide index={4}>
          <ImageWithZoom src={props.productDetails.images[4]} />
        </Slide>
      </Slider>
    </div>
  </CarouselProvider>*/}

                <div className="row">
                  <div className="col-xl-2 col-lg-2 col-md-2 col-sm-2">
                    <div id="img_dott1">
                      <ul className="clearfix" id="clfix">
                        {props.productDetails.length !== 0 && props.productDetails.images.map((contact) => (
                          <li style={{ marginBottom: '15px' }}>
                            <img src={contact} onMouseEnter={() => props.handleMouseEnter(contact)} style={{ height: '75px', width: '75px', border: '1px solid #cdcdcd' }} />
                            &nbsp;&nbsp;</li>

                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="col-xl-9 col-lg-9 col-md-10 col-12">
                    <div id="img-zm2">
                      <div className="img--zoom1" id="zoom3">
                        {props.productDetails.image && props.image0 === props.imageSrc &&
                          <Zoom
                            img={props.image0}
                            zoomScale={3}
                            height={300}
                            width={400}
                          />
                        }
                        {props.productDetails.image && props.image1 === props.imageSrc &&
                          <Zoom
                            img={props.image1}
                            zoomScale={3}
                            height={300}
                            width={400}
                          />
                        }
                        {props.productDetails.image && props.image2 === props.imageSrc &&
                          <Zoom
                            img={props.image2}
                            zoomScale={3}
                            height={300}
                            width={400}
                          />
                        }
                        {props.productDetails.image && props.image3 === props.imageSrc &&
                          <Zoom
                            img={props.image3}
                            zoomScale={3}
                            height={300}
                            width={400}
                          />
                        }
                        {props.productDetails.image && props.image4 === props.imageSrc &&
                          <Zoom
                            img={props.image4}
                            zoomScale={3}
                            height={300}
                            width={400}
                          />
                        }
                      </div>
                    </div>
                  </div>

                  {/*<div className="col-xl-1 col-lg-1 col-md-2 col-sm-2">
                          </div> */}

                </div>

                {/*------End - Product Detail Zoom----*/}
              </div>
              <div className="col-lg-5" id="col_pddetail">

                {/*------Product Right Side Details----*/}
                <div className="pd-detail" id="pdd-ddetail">
                  <div>

                    <span className="pd-detail__name">{props.productDetails.name}</span></div>
                  <div>
                    <div class="index-overallRatingContainer">
                      <div class="index-overallRating">
                        <div>{props.productDetails.rating_details[0].avgRating}</div>
                        <span class="myntraweb-sprite index-starIcon index-productRatingsGoodIcon sprites-productRatingsGoodIcon">
                        </span>
                        <div class="index-separator-data">|</div>
                        <div class="index-ratingsCount">{props.productDetails.rating_details[0].global_review} Ratings
                        </div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <div className="pd-detail__inline">

                      <span className="pd-detail__price">
                        &#8377;{props.productDetails.final_price}
                      </span>
                      <span
                        className={
                          props.productDetails.price -
                            props.productDetails.final_price !==
                            0
                            ? "product-strike"
                            : "product-nostrike"
                        }
                      >
                        &#8377;{props.productDetails.price}
                      </span>
                      <span
                        className={
                          props.productDetails.price -
                            props.productDetails.final_price !==
                            0
                            ? "product-discountPercentage"
                            : "product-nodiscountPercentage"
                        }
                      >
                        (
                        {Math.round(
                          ((props.productDetails.price -
                            props.productDetails.final_price) /
                            props.productDetails.price) *
                          100
                        )}
                        % OFF)
                      </span>
                    </div>
                  </div>
                  <span className="inclusive-text">inclusive of all taxes</span>
                  {/* <div className="u-s-m-b-15">
                                    <div className="pd-detail__rating gl-rating-style"><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i>

                                        <span className="pd-detail__review u-s-m-l-4">

                                            <a data-click-scroll="#view-review">23 Reviews</a></span></div>
                                </div> */}


                  <div className="u-s-m-b-15">
                    <div className="pd-detail__form">
                      {/* <div className="u-s-m-b-15">

                                            <span className="pd-detail__label u-s-m-b-8">Color:</span>
                                            <div className="pd-detail__color">
                                                <div className="color__radio">

                                                    <input type="radio" id="jet" name="color" checked/>

                                                    <label className="color__radio-label" for="jet" style={{backgroundColor: '#333333'}}></label></div>
                                                <div className="color__radio">

                                                    <input type="radio" id="folly" name="color"/>

                                                    <label className="color__radio-label" for="folly" style={{backgroundColor: '#FF0055'}}></label></div>
                                                <div className="color__radio">

                                                    <input type="radio" id="yellow" name="color"/>

                                                    <label className="color__radio-label" for="yellow" style={{backgroundColor: '#FFFF00'}}></label></div>
                                                <div class="color__radio">

                                                    <input type="radio" id="granite-gray" name="color"/>

                                                    <label className="color__radio-label" for="granite-gray" style={{backgroundColor: '#605F5E'}}></label></div>
                                                <div className="color__radio">

                                                    <input type="radio" id="space-cadet" name="color"/>

                                                    <label className="color__radio-label" for="space-cadet" style={{backgroundColor: '#1D3461'}}></label></div>
                                            </div>
                                        </div> */}
                      {/* <div className="u-s-m-b-15">

                                            <span className="pd-detail__label u-s-m-b-8">Size:</span>

                                        <div className="size-buttons-size-buttons"> 
                                            {props.productDetails.map((contact) => (
                                                <div className="size-buttons-tipAndBtnContainer">
                                                    <div className="size-buttons-buttonContainer">
                                                       {contact.qty !== 0 ?
                                                        <button onClick={() => props.sizeSelectData(contact)} className={props.prodChildSku === contact.sku ? "size-selected size-buttons-size-button size-buttons-size-button-default":"size-buttons-size-button size-buttons-size-button-default"}>
                                                                <span className="size-buttons-size-strike-hide">
                                                                </span>
                                                                <p className="size-buttons-unified-size">{contact.size}</p>
                                                        </button>
                                                        :
                                                        <button className="size-buttons-size-button size-buttons-size-button-default" style={{backgroundColor:'lightgrey'}}>
                                                                <span className="size-buttons-size-strike-hide">
                                                                </span>
                                                                <p className="size-buttons-unified-size">{contact.size}</p>
                                                        </button>
                                                         } 
                                                        {contact.qty < 5 ?
                                                        <span className={contact.qty === 0 ? "bar-not-display size-buttons-inventory-left":"size-buttons-inventory-left"} style={{bottom: '-1px'}}>
                                                            {contact.qty} Left
                                                        </span>
                                                        :<span></span>}
                                                    </div>
                                                </div>
                                            ))}
                                          </div>   



                                        </div>*/}
                      <div className="u-s-m-b-15">
                        <span className="pd-detail__label u-s-m-b-8">
                          Size:
                        </span>

                        <div className="size-buttons-size-buttons">
                          {props.productDetails.children_products.map(
                            (contact) => (
                              <div className="size-buttons-tipAndBtnContainer">
                                <div className="size-buttons-buttonContainer">
                                  {contact.qty !== 0 ? (
                                    <button
                                      onClick={() =>
                                        props.sizeSelectData(contact)
                                      }
                                      className={
                                        props.prodChildSku === contact.sku
                                          ? "size-selected size-buttons-size-button size-buttons-size-button-default"
                                          : "size-buttons-size-button size-buttons-size-button-default"
                                      }
                                    >
                                      <span className="size-buttons-size-strike-hide"></span>
                                      <p className="size-buttons-unified-size">
                                        {contact.name}
                                      </p>
                                    </button>
                                  ) : (
                                    <button
                                      className="size-buttons-size-button size-buttons-size-button-default"
                                      style={{
                                        backgroundColor: "lightgrey",
                                      }}
                                    >
                                      <span className="size-buttons-size-strike-hide"></span>
                                      <p className="size-buttons-unified-size">
                                        {contact.sku}
                                      </p>
                                    </button>
                                  )}
                                  {contact.qty < 5 ? (
                                    <span
                                      className={
                                        contact.qty === 0
                                          ? "bar-not-display size-buttons-inventory-left"
                                          : "size-buttons-inventory-left"
                                      }
                                      style={{ bottom: "-1px" }}
                                    >
                                      {contact.qty} Left
                                    </span>
                                  ) : (
                                    <span></span>
                                  )}
                                </div>
                              </div>
                            )
                          )}
                        </div>
                      </div>
                      <div className="pd-detail-inline-2">
                        <div className="u-s-m-b-15 pd_dt_15">

                          {/*--====== Input Counter ======*/}
                          <div className="input-counter">

                            <a onClick={props.DecreaseItem}><span className="input-counter__minus fas fa-minus"></span></a>

                            <input className="input-counter__text input-counter--text-primary-style" type="text" value={props.valueData} data-min="1" data-max="10" />

                            <a onClick={props.IncreaseItem}><span className="input-counter__plus fas fa-plus"></span></a>
                          </div>
                          {/*====== End - Input Counter ======*/}
                        </div>

                        <div className="u-s-m-b-15 detl_b15" id="qty_detl">
                          {(props.productDetails.length !== 0 && props.productDetails.qty !== 0) || props.dateObjectArray.length !== 0 ?
                            <button className="btn btn--e-brand-shadow" onClick={props.addProductToCart}><i className="fas fa-shopping-bag"></i>&nbsp;&nbsp;&nbsp;Add To Cart</button>
                            :
                            <button className="btn btn--e-brand-shadow brnd_shdw" disabled ><i className="fas fa-shopping-bag"></i>&nbsp;&nbsp;&nbsp;Add to Cart</button>
                          }
                          &nbsp;&nbsp;&nbsp;
                          {props.cartLoader === true &&
                            <img src={lazyLoader} alt="#" style={{ height: '60px', width: '60px' }} />
                          }
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="u-s-m-b-15">
                    <h4 style={{ fontWeight: '600' }}>Delivery Options&nbsp;&nbsp;&nbsp;<i className="fas fa-truck"></i></h4>

                    <div className="Address-switcher-container">
                      <div className="Address-address-box Address-pincode-input Address-pdp-box">
                        <input type="tel" name="zipCodeData" id="zipCodeData" placeholder="Enter a PIN code" value={props.zipCodeData} onChange={props.handleChangeZip} />
                        <button onClick={props.changeZipCode} type="submit" class="Address-address-button" style={{ color: 'black' }}>
                          CHECK</button>
                      </div>
                      {props.dateObjectArray.length !== 0 ?
                        <span style={{ color: '#0c7c3e' }}>Delivery Available</span>
                        : <span style={{ color: 'red' }}>Delivery Not Available</span>}
                    </div>
                  </div>
                  <p class="pincode-enterPincode">Please enter PIN code to check delivery time &amp; Pay on Delivery Availability</p>
                  <div className="u-s-m-b-15 meta-info">

                    {/* <p dangerouslySetInnerHTML={props.createMarkup(props.productDetails.short_description)}></p> */}
                    {props.productDetails.short_description.split("\r\n\r").map((i, key) => {
                      return <span className="meta-desc" key={key}>{i}<br /></span>;
                    })}
                  </div>

                  {/* <div className="u-s-m-b-15">
                                    <h4 style={{fontWeight:'600'}}>Product Details&nbsp;&nbsp;&nbsp;<i className="fas fa-truck"></i></h4>
                                      -----* <p dangerouslySetInnerHTML={props.createMarkup(props.productDetails.short_description)}></p> *-------
                                      {props.productDetails.description.split("\r\n").map((i,key) => {
                                       return <span className="meta-desc" key={key}>{i}<br/></span>;
                                    })}
                                </div> */}
                  {/* {props.productDetails.custom_fields[18].value !== false &&
                                <div className="u-s-m-b-15">
                                    <h4 style={{fontWeight:'600'}}>Size & Fit</h4>
                                    <span>{props.productDetails.custom_fields[26].value}</span>
                                     
                                </div>
                                 } 
                                 {props.productDetails.custom_fields[27].value !== false &&
                                <div className="u-s-m-b-15">
                                    <h4 style={{fontWeight:'600'}}>Material & Core</h4>
                                    <span>{props.productDetails.custom_fields[27].value}</span>
                                     
                                </div>
                                 } 
                                 <div className="u-s-m-b-15">
                                    <h4 style={{fontWeight:'600'}}>Specifications</h4>
                                    <div class="index-tableContainer">
                                       {props.productDetails.custom_fields[25].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Fabric</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[25].value}</div>
                                        </div>
                                         }
                                        {props.productDetails.custom_fields[22].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Pattern</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[22].value}</div>
                                        </div>
                                         }
                                         {props.productDetails.custom_fields[21].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Sleve Length</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[22].value}</div>
                                        </div>
                                         }
                                          {props.productDetails.custom_fields[5].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Wash Care</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[5].value}</div>
                                        </div>
                                         }
                                          {props.productDetails.custom_fields[19].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Neck</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[19].value}</div>
                                        </div>
                                         }
                                        {props.productDetails.custom_fields[24].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Sleeve Styling</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[24].value}</div>
                                        </div>
                                         }
                                          {props.productDetails.custom_fields[23].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Fabric Purity</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[23].value}</div>
                                        </div>
                                         }
                                          {props.productDetails.custom_fields[20].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Colour Family</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[20].value}</div>
                                        </div>
                                         }
                                         {props.productDetails.custom_fields[18].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Shape</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[18].value}</div>
                                        </div>
                                         }
                                        {props.productDetails.custom_fields[17].value !== null &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Length</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[17].value}</div>
                                        </div>
                                         }
                                          {props.productDetails.custom_fields[16].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Design Styling</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[16].value}</div>
                                        </div>
                                         }
                                           {props.productDetails.custom_fields[15].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Fashion Type</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[15].value}</div>
                                        </div>
                                         }
                                          {props.productDetails.custom_fields[14].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Print Or Pattern Type</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[14].value}</div>
                                        </div>
                                         }
                                          {props.productDetails.custom_fields[13].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Season</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[13].value}</div>
                                        </div>
                                         }
                                         {props.productDetails.custom_fields[12].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Usage</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[12].value}</div>
                                        </div>
                                         }
                                         {props.productDetails.custom_fields[11].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Weave Pattern</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[11].value}</div>
                                        </div>
                                         }
                                          {props.productDetails.custom_fields[10].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Slit Detail</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[10].value}</div>
                                        </div>
                                         }
                                          {props.productDetails.custom_fields[8].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Age Group</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[8].value}</div>
                                        </div>
                                         }
                                           {props.productDetails.custom_fields[7].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Stitch</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[7].value}</div>
                                        </div>
                                         }
                                          {props.productDetails.custom_fields[6].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Hemline</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[6].value}</div>
                                        </div>
                                         }
                                          {props.productDetails.custom_fields[5].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Wash care</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[5].value}</div>
                                        </div>
                                         }
                                          {props.productDetails.custom_fields[4].value !== false &&
                                        <div class="index-row">
                                            <div class="index-rowKey">Weave Type</div>
                                            <div class="index-rowValue">{props.productDetails.custom_fields[4].value}</div>
                                        </div>
                                         }
                                    </div>
                                     
                                </div>*/}

                  <div className="u-s-m-b-15 indx_flex15">
                    <h4 style={{ fontWeight: '600' }}>Ratings&nbsp;&nbsp;&nbsp;<i className="far fa-star"></i></h4>

                    <div class="index-flexRow index-margin22">
                      <div className="index-flexColumn">
                        {props.productReviewData !== undefined &&
                          <div className="index-flexRow index-averageRating">
                            <span>{props.productDetails.rating_details[0].avgRating}</span>
                            <i className="fas fa-star"></i>
                          </div>
                        }
                        {/* <div className="index-countDesc">
                                                    3.7k Verified Buyers
                                                 </div> */}
                      </div>
                      <div className="index-separator">
                      </div>

                      {props.productDetails !== undefined &&
                        <div>
                          <div className="index-flexRow index-ratingBarContainer">
                            <div className="index-rating">
                              <span className="index-ratingLevel">5</span>&nbsp;
                              <i className="fas fa-star"></i>
                            </div>&nbsp;
                            <progress min="0" max="250" value={props.productDetails.rating_details[0].new_rating[4].rating_count} data-rating="5"></progress>&nbsp;
                            <div className="index-count">{props.productDetails.rating_details[0].new_rating[4].rating_count}</div>
                          </div>
                          <div className="index-flexRow index-ratingBarContainer">
                            <div className="index-rating">
                              <span className="index-ratingLevel">4</span>&nbsp;
                              <i className="fas fa-star"></i>&nbsp;
                            </div>&nbsp;
                            <progress min="0" max="250" value={props.productDetails.rating_details[0].new_rating[3].rating_count} data-rating="4"></progress>&nbsp;
                            <div className="index-count">{props.productDetails.rating_details[0].new_rating[3].rating_count}</div>
                          </div>
                          <div className="index-flexRow index-ratingBarContainer">
                            <div className="index-rating">
                              <span className="index-ratingLevel">3</span>&nbsp;
                              <i className="fas fa-star"></i>&nbsp;
                            </div>&nbsp;
                            <progress min="0" max="250" value={props.productDetails.rating_details[0].new_rating[2].rating_count} data-rating="3"></progress>&nbsp;
                            <div className="index-count">{props.productDetails.rating_details[0].new_rating[2].rating_count}</div>
                          </div>
                          <div className="index-flexRow index-ratingBarContainer">
                            <div className="index-rating">
                              <span className="index-ratingLevel">2</span>&nbsp;
                              <i className="fas fa-star"></i>&nbsp;
                            </div>&nbsp;
                            <progress min="0" max="250" value={props.productDetails.rating_details[0].new_rating[1].rating_count} data-rating="2"></progress>&nbsp;
                            <div className="index-count">{props.productDetails.rating_details[0].new_rating[1].rating_count}</div>
                          </div>
                          <div className="index-flexRow index-ratingBarContainer">
                            <div className="index-rating">
                              <span className="index-ratingLevel">1</span>&nbsp;
                              <i className="fas fa-star"></i>&nbsp;
                            </div>&nbsp;
                            <progress min="0" max="250" value={props.productDetails.rating_details[0].new_rating[0].rating_count} data-rating="1"></progress>&nbsp;
                            <div className="index-count">{props.productDetails.rating_details[0].new_rating[0].rating_count}</div>
                          </div>
                        </div>
                      }
                    </div>


                    <hr style={{ color: '#a9abb3' }} />

                    <div className="u-s-m-b-15">
                      {props.productReviewData !== undefined &&
                        <h4 style={{ fontWeight: '600' }}>Customer Reviews ({props.productReviewData.items.length})</h4>
                      }
                      {props.productReviewData !== undefined && props.productReviewData.items1.map((contact) => (
                        <div className="user-review-userReviewWrapper row">
                          <div className="user-review-main user-review-showRating col-2">
                            <span class="user-review-starRating user-review-fiveStars">
                              {contact.ratings[0].value}
                              <span class="user-review-starIcon">
                                <i className="fas fa-star"></i>
                              </span>
                            </span>

                          </div>
                          <div class="user-review-reviewTextWrapper  col-10">{contact.detail}</div>

                        </div>
                      ))}
                    </div>
                    <hr style={{ color: '#a9abb3' }} />


                    <div style={{ marginTop: '10px', marginBottom: '-30%' }}>
                      <div className="row" id="btn_e_row">
                        <div className="col-md-12" id="btn_e_col">
                          <center>
                            <button onClick={() => props.toggleReviewModalFn()} className="btn btn--e-brand-shadow shdw">Write A Review</button>
                          </center>
                        </div>
                      </div>
                    </div>
                    <br />






                  </div>


                </div>
                {/*-====== End - Product Right Side Details ======*/}
              </div>
            </div>
          </div>
        </div>

        {/*  <div className="u-s-p-t-90">
                <div style={{marginLeft:'25px',marginRight:'25px'}}>
                    <h4>Related Product</h4>
                     <div className="row">
                     {props.relatedData !== undefined && props.relatedData.map((contact) => (
                         <div className="col-lg-3 col-md-3 col-sm-6 u-s-m-b-30">
                    <div className="product-m">
                      <div className="product-m__thumb">
                        <a
                          className="aspect u-d-block"
                          href={"/product/" + `${contact.sku}`}
                        >
                          <SimpleImageSlider
                            width={250}
                            height={320}
                            images={contact.images_data}
                            alt={contact.name}
                            showBullets={true}
                            slideDuration={0.5}
                            autoplay={true}
                          />
                        </a>
                      </div>
                      <div className="product-m__content">
                        <div className="product-m__category">
                          <a href={"/product/" + `${contact.sku}`}>
                            {contact.name}
                          </a>
                        </div>

                        <div className="product-m__price">
                          <span>
                            <span className="product-discountedPrice">
                              &#8377;{contact.final_price}
                            </span>
                            <span
                              className={
                                contact.price - contact.final_price !== 0
                                  ? "product-strike"
                                  : "product-nostrike"
                              }
                            >
                              &#8377;{contact.price}
                            </span>
                          </span>
                          <span
                            className={
                              contact.price - contact.final_price !== 0
                                ? "product-discountPercentage"
                                : "product-nodiscountPercentage"
                            }
                          >
                            (
                            {Math.round(
                              ((contact.price - contact.final_price) /
                                contact.price) *
                                100
                            )}
                            % OFF)
                          </span>
                        </div>
                        <div className="product-m__hover">
                          <b>Sizes:&nbsp;</b>
                          {contact.children_products.map((key) => (
                            <span className="product-sizeNoInventoryPresent">
                              {key.size} &nbsp;
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                     ))}    

                     </div>
                  </div>
            </div>   */}


        {/* {props.children && !_isEmpty(props.children) && (
    <div className="u-s-p-b-60 alice_top" id="crousel-top">
      <div id="crous-img">
      <div className="container">
        <div className="row sub_content">
          <div className="col-md-12">
              <div className="dividerHeading" id="divd_headd">
                <center><h2 id="hdd_may"><span>You May Also Like</span></h2></center>
              </div>

              <br/>
            <div className="container">
                <AliceCarousel
                    items={props.children}
                    responsive={props.responsive}
                    slideToIndex={props.currentIndex}
                    mouseTrackingEnabled={true}
                    onSlideChange={props.onSlideChange}
                    onSlideChanged={props.onSlideChanged}
                  /> 
            </div>    
          </div>
        </div>
      </div>
      </div>    
    </div>
 )} */}





        {/*  {
                     props.showReviewModal &&
                    <MaModal open={props.showReviewModal} handleCloseModal={() => props.toggleReviewModalFn()}>
                   
                    <div className="row" style={{backgroundColor:'#923150',marginTop:'-20px',height:'64px',marginLeft:'0px',marginRight:'0px'}}>
                    <div className="col-md-3"></div>
                    <div className="col-md-6"> <center><h3 style={{color:'white',paddingTop:'9px'}}>Rate and  Review</h3>
                      
                      </center></div>
                      <div className="col-md-3"><a style={{padding:'20px',cursor:'pointer',float:'right',color:'white'}} onClick={() => props.toggleReviewModalFn()}>X</a></div>
                    </div> 
                     <br/>
                   
                      <div>
                         <center>   <p>Your review will be publically posted on our website.</p>
                          <br/> 
                               <StarRatings
                                rating={props.rating}
                                starRatedColor="blue"
                                starDimension="25px"
                                starSpacing="1px"
                                changeRating={props.changeRating}
                                numberOfStars={5}
                                name='rating'
                                className="field-input"
                            />
                             <br /><span style={{ color: 'red' }}>{props.errors.rating}</span>
                            <br/>
                            {props.loginData === '' ?
                       <div></div>
                       
                     :  <h3 style={{textTransform:'none'}}>{props.userFirstName} </h3>}
                       <div>
                         <input style={{width:'400px',borderTopStyle: 'hidden',borderRightStyle: 'hidden',borderLeftStyle: 'hidden',borderBottomStyle: 'groove'}} type="text" className="no-outline" placeholder="Enter Title" onChange={props.handleChange} name="review_title"/>
                         <br /><span style={{ color: 'red' }}>{props.errors.review_title}</span>
                       </div>
                       <br/>
                       <br/>
                       <div>
                          <textarea rows={4} style={{width:'400px',borderTopStyle: 'hidden',borderRightStyle: 'hidden',borderLeftStyle: 'hidden',borderBottomStyle: 'groove'}} type="text" className="no-outline" placeholder="Share details of your experience with Cottinfab" onChange={props.handleChange} name="review_details"></textarea>
                            <br/><span style={{ color: 'red' }}>{props.errors.review_details}</span>
                       </div>
                         <br/>
                       {props.reviewPostLoader  ?
                          <img src={ lazyLoader } style={{height:'60px',width:'60px'}}  alt="lazy-loader"/>
                        : <button type="button" style={{height:'50px',width:'200px',backgroundColor:'#923150',border:'1px solid',borderRadius:'35px',color:'white'}} className="" onClick={() => props.submitReviews()}>Post</button>}
                        </center>
                     </div>
                  </MaModal>
                }  */}

        {props.showReviewModal && (
          <MaModal
            open={props.showReviewModal}
            handleCloseModal={() => props.toggleReviewModalFn()}
          >
            <div className="mkSty-pr2" id="mk-styl">
              <div id="mkstyle45">
                <div
                  className="row rate-roow2" id="rate_row3"
                  style={{
                    backgroundColor: "#633974",
                    marginTop: "-20px",
                    height: "64px",
                    marginRight: "0px",
                  }}
                >
                  <div className="col-md-3"></div>
                  <div className="col-md-6">
                    {" "}
                    <center>
                      <h3 id="rate5" style={{ color: "white", paddingTop: "16px" }}>
                        Rate and Review
                      </h3>
                    </center>
                  </div>
                  <div className="col-md-3" id="cross-md">
                    <a
                      style={{ padding: "20px", cursor: "pointer", float: "right", color: "white" }}
                      onClick={() => props.toggleReviewModalFn()}
                    >
                      X
                    </a>
                  </div>
                </div>
                <br />

                <div>
                  <center>
                    {" "}
                    <p style={{ color: "black", fontSize: "18px", fontWeight: "400" }}>Your Review Will Be Publically Posted On Sanskriti :-)</p>
                    <br />
                    <StarRatings
                      rating={props.rating}
                      starRatedColor="#633974"
                      starDimension="25px"
                      starSpacing="1px"
                      changeRating={props.changeRating}
                      numberOfStars={5}
                      name="rating"
                      className="field-input"
                    />
                    <br />
                    <span style={{ color: "red" }}>{props.errors.rating}</span>
                    <br />
                    {props.loginData === "" ? (
                      <div></div>
                    ) : (
                      <h3 style={{ textTransform: "none" }}>
                        {props.userFirstName}{" "}
                      </h3>
                    )}
                    <div className="cointainer">
                      <center>
                        <div className="row">
                          <div className="col-md-9 col-9">
                            <input
                              style={{
                                borderTopStyle: "hidden",
                                borderRightStyle: "hidden",
                                borderLeftStyle: "hidden",
                                borderBottomStyle: "groove",
                                marginTop: "20px",
                                marginRight: "-135px",
                              }}
                              type="text"
                              maxLength="50"
                              className="no-outline Werty123"
                              placeholder="Enter Title"
                              onChange={props.handleChange1}
                              name="review_title"
                              id="ent-tlt"
                            />
                          </div>
                          <div className="col-md-3 col-3">
                            <p className="char_lft" id="inpt_chr_lt">{props.chars_left1}</p>
                          </div>
                        </div>
                      </center>
                      <br />
                      <span style={{ color: "red" }}>
                        {props.errors.review_title}
                      </span>
                    </div>
                    <br />
                    <br />
                    <div className="container">
                      <div className="row">
                        <div className="col-md-9 col-9">
                          <textarea
                            rows={4}
                            style={{
                              borderTopStyle: "hidden",
                              borderRightStyle: "hidden",
                              borderLeftStyle: "hidden",
                              borderBottomStyle: "groove",
                              marginRight: "-135px",
                            }}
                            type="text"
                            maxLength="120"
                            // onChange={this.handleWordCount}
                            className="no-outline Werty123"
                            placeholder="Tell us about your experience!"
                            onChange={props.handleChange}
                            name="review_details"
                            id="exp-area"
                          >
                          </textarea>
                        </div>
                        <div className="col-md-3 col-3">
                          <p className="char_lft2" id="int_chr_lt2">{props.chars_left}</p>
                        </div>
                      </div>
                      <br />
                      <span style={{ color: "red" }}>
                        {props.errors.review_details}
                      </span>
                    </div>
                    <br />
                    {props.reviewPostLoader ? (
                      <img
                        src={lazyLoader}
                        style={{ height: "60px", width: "60px" }}
                        alt="lazy-loader"
                      />
                    ) : (
                      <button
                        type="button"
                        style={{
                          height: "50px",
                          width: "200px",
                          backgroundColor: "#633974",
                          border: "1px solid",
                          borderRadius: "35px",
                          color: "white",
                          fontSize: "20px",
                          marginBottom: "60px",
                        }}
                        className=""
                        onClick={() => props.submitReviews()}
                      >
                        Post
                      </button>
                    )}
                  </center>
                </div>
              </div>
            </div>
          </MaModal>
        )}






      </div>



    );

  }
  return (<div> '' </div>);
}
