import uuidv1 from 'uuid/v1';

const generateV1uuid = () => uuidv1();

export { generateV1uuid };
