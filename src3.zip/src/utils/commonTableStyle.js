export const columnStyle = {
        whiteSpace: 'normal',
        wordWrap: 'break-word'
    };

export const columnStyle2 = {
    verticalAlign: 'top',
    whiteSpace: 'normal',
    wordWrap: 'break-word'
};