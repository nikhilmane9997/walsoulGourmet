const AUTH_HEADER_KEY = 'Authorization';
const CORRELATION_ID_KEY = 'correlationId';

export {
  AUTH_HEADER_KEY,
  CORRELATION_ID_KEY,
};
